package com.codix.vip

import android.content.Context
import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyPermanentlyInvalidatedException
import android.security.keystore.KeyProperties
import android.security.keystore.UserNotAuthenticatedException
import android.util.Base64
import org.json.JSONObject
import java.io.File
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * تخزين مشفر بمفاتيح Android Keystore (AES-256-GCM). المفاتيح لا تغادر الجهاز ولا يمكن استخراجها.
 *
 * - مفتاح البيانات: لا يطلب مصادقة، ويشفّر ملف الحسابات والسجل والمفضلة والإعدادات.
 * - مفتاح كلمات السر: يتطلب مصادقة حديثة (بصمة أو قفل الجهاز خلال 30 ثانية) لكل تشفير أو فك.
 */
class SecureStore(private val ctx: Context) {

    private val ks: KeyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
    private val dataFile = File(ctx.filesDir, "codix.dat")
    private val pinFile = File(ctx.filesDir, "codix.pins")

    companion object {
        private const val MASTER = "codix_master_v1"
        private const val PINKEY = "codix_pin_v1"
        private const val AUTH_SECONDS = 30
    }

    // ---------- المفاتيح ----------

    private fun masterKey(): SecretKey {
        (ks.getKey(MASTER, null) as? SecretKey)?.let { return it }
        val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        kg.init(
            KeyGenParameterSpec.Builder(
                MASTER, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return kg.generateKey()
    }

    @Suppress("DEPRECATION")
    private fun pinKey(): SecretKey {
        (ks.getKey(PINKEY, null) as? SecretKey)?.let { return it }
        val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        val b = KeyGenParameterSpec.Builder(
            PINKEY, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .setUserAuthenticationRequired(true)
        if (Build.VERSION.SDK_INT >= 30) {
            b.setUserAuthenticationParameters(
                AUTH_SECONDS,
                KeyProperties.AUTH_DEVICE_CREDENTIAL or KeyProperties.AUTH_BIOMETRIC_STRONG
            )
        } else {
            b.setUserAuthenticationValidityDurationSeconds(AUTH_SECONDS)
        }
        if (Build.VERSION.SDK_INT >= 24) b.setInvalidatedByBiometricEnrollment(false)
        kg.init(b.build())
        return kg.generateKey()
    }

    private fun seal(key: SecretKey, plain: ByteArray): ByteArray {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key)
        return c.iv + c.doFinal(plain)
    }

    private fun open(key: SecretKey, blob: ByteArray): ByteArray {
        val iv = blob.copyOfRange(0, 12)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
        return c.doFinal(blob, 12, blob.size - 12)
    }

    // ---------- بيانات التطبيق (حسابات، سجل، مفضلة، إعدادات) ----------

    /** يعيد JSON: {ok, data, reason}. عند تلف الملف يُنقل إلى نسخة .bak ويبدأ التطبيق ببيانات فارغة. */
    fun loadData(): String {
        val out = JSONObject()
        if (!dataFile.exists()) return out.put("ok", true).put("data", "").toString()
        return try {
            val text = String(open(masterKey(), dataFile.readBytes()), Charsets.UTF_8)
            out.put("ok", true).put("data", text).toString()
        } catch (e: Exception) {
            try {
                dataFile.renameTo(File(ctx.filesDir, "codix.dat.bak"))
            } catch (_: Exception) {
            }
            out.put("ok", false).put("reason", "unreadable").put("data", "").toString()
        }
    }

    fun saveData(json: String): Boolean {
        return try {
            val blob = seal(masterKey(), json.toByteArray(Charsets.UTF_8))
            val tmp = File(ctx.filesDir, "codix.dat.tmp")
            tmp.writeBytes(blob)
            if (!tmp.renameTo(dataFile)) {
                dataFile.delete()
                tmp.renameTo(dataFile)
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    // ---------- كلمات السر ----------

    private fun readPins(): JSONObject = try {
        if (pinFile.exists()) JSONObject(pinFile.readText()) else JSONObject()
    } catch (_: Exception) {
        JSONObject()
    }

    private fun writePins(o: JSONObject) {
        pinFile.writeText(o.toString())
    }

    fun hasPin(key: String): Boolean = readPins().has(key)

    /** يعيد JSON: {ok} أو {ok:false, reason}. يحتاج مصادقة حديثة. */
    fun savePin(key: String, pin: String): String {
        val out = JSONObject()
        return try {
            val blob = seal(pinKey(), pin.toByteArray(Charsets.UTF_8))
            val pins = readPins()
            pins.put(key, Base64.encodeToString(blob, Base64.NO_WRAP))
            writePins(pins)
            out.put("ok", true).toString()
        } catch (e: UserNotAuthenticatedException) {
            out.put("ok", false).put("reason", "auth_required").toString()
        } catch (e: KeyPermanentlyInvalidatedException) {
            wipePins()
            out.put("ok", false).put("reason", "invalidated").toString()
        } catch (e: Exception) {
            out.put("ok", false).put("reason", "unavailable").toString()
        }
    }

    /** يعيد JSON: {ok, pin} أو {ok:false, reason}. يحتاج مصادقة حديثة. */
    fun getPin(key: String): String {
        val out = JSONObject()
        val enc = readPins().optString(key, "")
        if (enc.isEmpty()) return out.put("ok", false).put("reason", "none").toString()
        return try {
            val plain = open(pinKey(), Base64.decode(enc, Base64.NO_WRAP))
            out.put("ok", true).put("pin", String(plain, Charsets.UTF_8)).toString()
        } catch (e: UserNotAuthenticatedException) {
            out.put("ok", false).put("reason", "auth_required").toString()
        } catch (e: KeyPermanentlyInvalidatedException) {
            wipePins()
            out.put("ok", false).put("reason", "invalidated").toString()
        } catch (e: Exception) {
            out.put("ok", false).put("reason", "unavailable").toString()
        }
    }

    fun removePin(key: String) {
        val pins = readPins()
        pins.remove(key)
        writePins(pins)
    }

    private fun wipePins() {
        try {
            pinFile.delete()
            ks.deleteEntry(PINKEY)
        } catch (_: Exception) {
        }
    }
}
