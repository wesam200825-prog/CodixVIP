package com.codix.vip

import android.app.Activity
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.WindowInsets
import android.view.WindowManager
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.window.OnBackInvokedDispatcher

/**
 * غلاف WebView يحمّل واجهة CodiX VIP Pro من ملفات التطبيق المحلية فقط.
 * لا يوجد اتصال بالإنترنت ولا تنقّل لأي رابط خارجي.
 */
class MainActivity : Activity() {

    private lateinit var web: WebView
    private lateinit var bridge: NativeBridge

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // حماية الشاشة (منع لقطات الشاشة ومعاينة التطبيقات الأخيرة) مفعلة افتراضيًا
        window.setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE
        )

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.parseColor("#0F172A"))
        // من Android 15 فما فوق تمتد الواجهة تحت شريطي النظام؛ نضيف هوامش النظام يدويًا
        root.setOnApplyWindowInsetsListener { v, insets ->
            if (Build.VERSION.SDK_INT >= 30) {
                val i = insets.getInsets(
                    WindowInsets.Type.systemBars() or
                        WindowInsets.Type.displayCutout() or
                        WindowInsets.Type.ime()
                )
                v.setPadding(i.left, i.top, i.right, i.bottom)
            } else {
                @Suppress("DEPRECATION")
                v.setPadding(
                    insets.systemWindowInsetLeft,
                    insets.systemWindowInsetTop,
                    insets.systemWindowInsetRight,
                    insets.systemWindowInsetBottom
                )
            }
            insets
        }

        web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#0F172A"))
        root.addView(
            web,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        )
        setContentView(root)

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.allowFileAccess = false
        s.allowContentAccess = false
        s.blockNetworkLoads = true
        s.cacheMode = WebSettings.LOAD_NO_CACHE
        s.setSupportZoom(false)
        s.builtInZoomControls = false
        s.textZoom = 100

        val debuggable = (applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0
        WebView.setWebContentsDebuggingEnabled(debuggable)

        web.webViewClient = object : WebViewClient() {
            // نسمح فقط بصفحات التطبيق المحلية
            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean = !request.url.toString().startsWith("file:///android_asset/www/")
        }

        bridge = NativeBridge(this, web)
        web.addJavascriptInterface(bridge, "CodixNative")
        web.loadUrl("file:///android_asset/www/index.html")

        if (Build.VERSION.SDK_INT >= 33) {
            onBackInvokedDispatcher.registerOnBackInvokedCallback(
                OnBackInvokedDispatcher.PRIORITY_DEFAULT
            ) { handleBack() }
        }
    }

    /** نسأل الواجهة أولًا: إن كانت لديها نافذة أو شاشة مفتوحة تغلقها، وإلا نغلق التطبيق. */
    private fun handleBack() {
        web.evaluateJavascript(
            "(function(){return !!(window.onNativeBack && window.onNativeBack());})()"
        ) { r -> if (r != "true") finish() }
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        handleBack()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        bridge.onPermissionsResult()
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        bridge.onActivityResultFromSystem(requestCode, resultCode)
    }

    override fun onPause() {
        super.onPause()
        if (::bridge.isInitialized) bridge.emitLifecycle("pause")
    }

    override fun onResume() {
        super.onResume()
        if (::bridge.isInitialized) bridge.emitLifecycle("resume")
    }

    override fun onDestroy() {
        web.removeJavascriptInterface("CodixNative")
        web.destroy()
        super.onDestroy()
    }
}
