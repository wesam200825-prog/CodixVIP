/* CodiX VIP Pro - منطق الواجهة. لا innerHTML إطلاقًا: كل النصوص (وردود الشبكة) تُدرج كنص فقط. */
(function () {
  'use strict';

  var P = window.Providers, S = window.Store, N = window.Native;
  function $(id) { return document.getElementById(id); }

  var ui = {
    tab: 'home', sims: [], simsOk: false, device: {}, perms: { call: false, phoneState: false },
    busy: false, sheetOpen: false, sheetLocked: false,
    opsStatus: 'all', opsService: 'all', opsToday: false, opsQuery: '', expanded: {},
    balLoading: {}, balErr: {}, hasSavedPin: false, hiddenAt: 0, locked: false
  };

  // ---------- أدوات ----------

  function add(el, c) {
    if (c == null || c === false) return;
    if (Array.isArray(c)) { c.forEach(function (x) { add(el, x); }); return; }
    if (c.nodeType) { el.appendChild(c); return; }
    el.appendChild(document.createTextNode(String(c)));
  }
  function h(tag, props) {
    var el = document.createElement(tag);
    props = props || {};
    Object.keys(props).forEach(function (k) {
      var v = props[k];
      if (v == null || v === false) return;
      if (k === 'class') el.className = v;
      else if (k === 'text') el.textContent = v;
      else if (k.slice(0, 2) === 'on') el.addEventListener(k.slice(2), v);
      else el.setAttribute(k, v === true ? '' : v);
    });
    for (var i = 2; i < arguments.length; i++) add(el, arguments[i]);
    return el;
  }
  function clear(el) { while (el.firstChild) el.removeChild(el.firstChild); }

  var toastTimer = null;
  function toast(msg) {
    var t = $('toast');
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.classList.remove('show'); }, 2800);
  }

  function money(n) { return '₪ ' + Number(n || 0).toLocaleString('en-US', { maximumFractionDigits: 2 }); }
  function timeStr(ts) {
    var d = new Date(ts);
    return d.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }) + ' | ' + d.toLocaleDateString('ar-EG');
  }
  function ago(ts) {
    var m = Math.max(0, Math.round((Date.now() - ts) / 60000));
    if (m < 1) return 'قبل أقل من دقيقة';
    if (m < 60) return 'قبل ' + m + ' دقيقة';
    var hh = Math.round(m / 60);
    if (hh < 48) return 'قبل ' + hh + ' ساعة';
    return 'قبل ' + Math.round(hh / 24) + ' يوم';
  }

  var STATUS_LABEL = { success: 'ناجحة', failed: 'فاشلة', pending: 'قيد المعالجة', unconfirmed: 'غير مؤكدة' };
  function statusTag(e) {
    var txt = STATUS_LABEL[e.status] || e.status;
    if (e.manual && e.status !== 'pending') txt += ' (تأكيد يدوي)';
    if (e.legacy) txt = 'قديمة غير مؤكدة';
    return h('span', { class: 'status ' + (e.legacy ? 'unconfirmed' : e.status), text: txt });
  }

  // ---------- المظهر ----------

  function isDark() {
    var t = S.d.settings.theme;
    if (t === 'dark') return true;
    if (t === 'light') return false;
    return !!(window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches);
  }
  function applyTheme() {
    var dark = isDark();
    document.body.classList.toggle('dark-mode', dark);
    $('darkModeBtn').textContent = dark ? '☀️' : '🌙';
    var prov = P.get(S.d.ui.service, S.d.ui.network);
    var root = document.documentElement;
    root.style.setProperty('--primary-color', prov.color);
    root.style.setProperty('--bg-solid', dark ? '#0f172a' : prov.color);
  }

  // ---------- النوافذ السفلية ----------

  function closeSheet() {
    clear($('sheetRoot'));
    ui.sheetOpen = false;
    ui.sheetLocked = false;
  }
  function openSheet(build, opts) {
    closeSheet();
    opts = opts || {};
    var ov = h('div', { class: 'sheet-overlay' });
    var sh = h('div', { class: 'sheet', role: 'dialog', 'aria-modal': 'true' });
    ov.addEventListener('click', function (e) { if (e.target === ov && !ui.sheetLocked) closeSheet(); });
    sh.appendChild(build(closeSheet));
    ov.appendChild(sh);
    $('sheetRoot').appendChild(ov);
    ui.sheetOpen = true;
    ui.sheetLocked = !!opts.locked;
    return sh;
  }

  function askText(title, label, initial, okLabel) {
    return new Promise(function (resolve) {
      var done = false;
      function fin(v) { if (done) return; done = true; closeSheet(); resolve(v); }
      openSheet(function () {
        var inp = h('input', { class: 'field', type: 'text', value: initial || '', 'aria-label': label });
        inp.value = initial || '';
        return h('div', {},
          h('h2', { text: title }),
          h('label', { class: 'f', text: label }), inp,
          h('div', { class: 'btn-row' },
            h('button', { class: 'btn', text: okLabel || 'حفظ', onclick: function () { fin(inp.value); } }),
            h('button', { class: 'btn sec', text: 'إلغاء', onclick: function () { fin(null); } })));
      });
    });
  }

  function askConfirm(title, message, okLabel, danger) {
    return new Promise(function (resolve) {
      var done = false;
      function fin(v) { if (done) return; done = true; closeSheet(); resolve(v); }
      openSheet(function () {
        return h('div', {},
          h('h2', { text: title }), h('p', { text: message }),
          h('div', { class: 'btn-row' },
            h('button', { class: 'btn' + (danger ? ' danger' : ''), text: okLabel || 'تأكيد', onclick: function () { fin(true); } }),
            h('button', { class: 'btn sec', text: 'إلغاء', onclick: function () { fin(false); } })));
      });
    });
  }

  // ---------- الشرائح والحسابات ----------

  function refreshDevice() {
    ui.device = N.device();
    ui.perms = N.permissions();
    var r = N.sims();
    ui.simsOk = !!r.ok;
    ui.sims = r.sims || [];
  }
  function simOf(acc) {
    if (!acc || acc.subId == null) return null;
    return ui.sims.filter(function (s) { return s.subId === acc.subId; })[0] || null;
  }
  function simName(s) { return 'الشريحة ' + (s.slot + 1) + ' - ' + (s.carrier || s.display || '؟'); }

  function accountStatus(acc) {
    if (!N.available) return { cls: 'off', text: 'التنفيذ الداخلي غير متاح في المتصفح' };
    if (!ui.perms.phoneState) return { cls: 'warn', text: 'امنح صلاحية حالة الهاتف لقراءة الشرائح' };
    if (acc.subId == null) {
      return ui.sims.length > 1 ? { cls: 'warn', text: 'غير مرتبط بشريحة (اربطه قبل التنفيذ)' }
                                : { cls: 'ok', text: 'يستخدم الشريحة الافتراضية' };
    }
    var s = simOf(acc);
    if (!s) return { cls: 'warn', text: 'الشريحة المرتبطة غير موجودة الآن' };
    return { cls: 'ok', text: 'متصل: ' + simName(s) };
  }

  function accountsFor(prov) {
    return S.d.accounts.filter(function (a) {
      return a.service === prov.service && (prov.service !== 'jawwal' || a.network === prov.network);
    });
  }
  function pickAccount(prov) {
    var list = accountsFor(prov);
    var cur = list.filter(function (a) { return a.id === S.d.ui.accountId; })[0];
    return cur || list.filter(function (a) { return a.isDefault; })[0] || list[0] || null;
  }
  function currentProv() { return P.get(S.d.ui.service, S.d.ui.network); }
  function currentAccount() { return pickAccount(currentProv()); }
  function syncAccount() {
    var a = currentAccount();
    S.d.ui.accountId = a ? a.id : null;
  }
  function provOfAccount(a) { return P.get(a.service, a.network); }
  function accountLabel(a) { return a.name || provOfAccount(a).label; }
  function pinKeyFor(prov, acc) { return acc ? 'acc_' + acc.id : 'svc_' + prov.key.replace(':', '_'); }

  // النمط الفعلي للتنفيذ: داخل التطبيق أو عبر تطبيق الاتصال
  function execMode(prov) {
    if (!N.available) return { mode: 'dialer', why: 'أنت تستخدم المتصفح: لا يتوفر التنفيذ الداخلي' };
    if (!S.d.settings.inApp) return { mode: 'dialer', why: 'التنفيذ الداخلي معطّل من الإعدادات' };
    if (!prov.inApp) return { mode: 'dialer', why: 'هذه الخدمة تحتاج خطوات تفاعلية لا تدعمها الواجهة الرسمية' };
    if (!ui.device.ussdApiSupported) return { mode: 'dialer', why: 'جهازك أقدم من Android 8' };
    if (!ui.perms.call) return { mode: 'dialer', why: 'صلاحية الاتصال غير ممنوحة' };
    return { mode: 'inapp', why: '' };
  }
  // شريحتان ولا ربط: نمنع الإرسال الداخلي حتى لا ينفذ على الشريحة الخطأ
  function simGuard(acc) {
    if (ui.sims.length > 1) {
      if (!acc || acc.subId == null) return 'اربط الحساب بشريحة من تبويب الحسابات قبل التنفيذ داخل التطبيق';
      if (!simOf(acc)) return 'الشريحة المرتبطة بهذا الحساب غير موجودة، أعد ربطها من تبويب الحسابات';
    }
    return '';
  }

  // ---------- نموذج التحويل (الصفحة الرئيسية) ----------

  function formValues() {
    return {
      type: S.d.ui.type || '1',
      phone: $('phone').value.trim(),
      amount: $('amount').value.trim(),
      pin: $('pin').value.trim()
    };
  }
  function cleanPhone(val) {
    var c = String(val).replace(/\D/g, '');
    if (c.indexOf('00970') === 0) c = '0' + c.slice(5);
    else if (c.indexOf('00972') === 0) c = '0' + c.slice(5);
    else if (c.indexOf('970') === 0) c = '0' + c.slice(3);
    else if (c.indexOf('972') === 0) c = '0' + c.slice(3);
    return c;
  }

  function updateCode() {
    var prov = currentProv();
    $('previewCode').textContent = P.previewCode(prov, formValues());
  }

  function updatePinState() {
    var prov = currentProv(), acc = currentAccount();
    var key = pinKeyFor(prov, acc);
    ui.hasSavedPin = N.available && N.pin.has(key);
    var cb = $('savePinCheckbox');
    cb.checked = ui.hasSavedPin;
    var supported = N.available && N.pin.supported();
    $('savePinWrap').style.display = N.available ? '' : 'none';
    cb.disabled = N.available && !supported;
    var hint = '';
    if (ui.hasSavedPin) hint = 'كلمة السر محفوظة ومشفرة بمفتاح الجهاز. اترك الحقل فارغًا لاستخدامها (تُطلب البصمة).';
    else if (N.available && !supported) hint = 'لحفظ كلمة السر يجب تفعيل قفل شاشة (بصمة أو رمز) على الجهاز.';
    $('pinHint').textContent = hint;
    $('pin').placeholder = ui.hasSavedPin ? 'محفوظة' : '••••';
  }

  function renderAccountBar() {
    var bar = $('accountBar');
    clear(bar);
    var prov = currentProv();
    var list = accountsFor(prov);
    var cur = currentAccount();
    list.forEach(function (a) {
      bar.appendChild(h('button', {
        class: 'account-chip' + (cur && cur.id === a.id ? ' active' : ''),
        text: (a.isDefault ? '★ ' : '') + accountLabel(a) + (a.phone ? ' · ' + a.phone : ''),
        onclick: function () { S.d.ui.accountId = a.id; S.save(); renderAccountBar(); updatePinState(); }
      }));
    });
    if (!list.length) {
      bar.appendChild(h('button', { class: 'account-chip', text: '+ أضف حسابًا لـ ' + prov.label, onclick: function () { showTab('accounts'); openAccountSheet(null, prov); } }));
    }
  }

  function setService(service) {
    S.d.ui.service = service;
    var prov = currentProv();
    ['jawwal', 'palpay', 'bop'].forEach(function (s) {
      var id = s === 'jawwal' ? 'btnServiceJawwal' : (s === 'palpay' ? 'btnServicePalpay' : 'btnServiceBop');
      $(id).classList.toggle('active', s === service);
    });
    $('networkContainer').style.display = service === 'jawwal' ? 'flex' : 'none';
    $('typeContainer').style.display = prov.hasType ? 'flex' : 'none';
    $('phoneContainer').style.display = prov.needsPhone ? 'block' : 'none';
    $('amountContainer').style.display = prov.needsAmount ? 'block' : 'none';
    $('balanceBtn').style.display = prov.balanceCode ? 'block' : 'none';
    $('pinContainer').style.display = prov.needsPin ? 'block' : 'none';
    $('clearOnlyWrap').hidden = prov.needsPin || !prov.needsPhone;
    $('submitBtn').textContent = prov.kind === 'login' ? 'الدخول للخدمة 📞' : 'تحويل 📞';
    $('pinLabel').textContent = 'كلمة السر (4 أرقام)';
    syncAccount();
    applyTheme();
    renderAccountBar();
    updatePinState();
    updateCode();
    S.save();
  }

  function setNetwork(net) {
    S.d.ui.network = net;
    $('btnNetJawwal').className = 'network-btn' + (net === 'jawwal' ? ' active-jawwal' : '');
    $('btnNetOoredoo').className = 'network-btn' + (net === 'ooredoo' ? ' active-ooredoo' : '');
    syncAccount();
    applyTheme();
    renderAccountBar();
    updatePinState();
    updateCode();
    S.save();
  }

  function setType(type) {
    S.d.ui.type = type;
    $('btnFriend').className = 'toggle-btn' + (type === '1' ? ' active' : '');
    $('btnMerchant').className = 'toggle-btn' + (type === '2' ? ' active' : '');
    updateCode();
  }

  function clearInputs() {
    $('phone').value = '';
    $('amount').value = '';
    detectName('');
    updateCode();
    toast('تم تفريغ الحقول');
  }

  // ---------- الأسماء والمفضلة ----------

  function savedNameFor(phone) {
    if (!phone || phone.length < 10) return null;
    var f = S.d.favorites.filter(function (x) { return x.phone === phone && x.name; })[0];
    if (f) return f.name;
    var hh = S.d.history.filter(function (x) { return x.phone === phone && x.name; })[0];
    return hh ? hh.name : null;
  }
  function detectName(phone) {
    var badge = $('detectedNameBadge');
    var name = savedNameFor(phone);
    if (name) { $('detectedNameText').textContent = name; badge.style.display = 'flex'; }
    else badge.style.display = 'none';
  }
  function validPhone(p) { return /^05\d{8}$/.test(p); }

  function renderFavorites() {
    var bar = $('favoritesBar');
    clear(bar);
    var favs = S.d.favorites.slice().sort(function (a, b) { return (b.uses || 0) - (a.uses || 0); });
    if (!favs.length) { bar.style.display = 'none'; return; }
    bar.style.display = 'flex';
    favs.forEach(function (f) {
      bar.appendChild(h('div', { class: 'fav-chip', onclick: function () { useFavorite(f.phone); } },
        '⭐ ', h('strong', { text: f.name ? f.name + ' (' + f.phone + ')' : f.phone }),
        h('span', { class: 'tag', text: f.type === '2' ? '🏪 تاجر' : '👤 شخص' }),
        h('span', { class: 'fav-edit-btn', title: 'تعديل الاسم', text: '✏️', onclick: function (e) { e.stopPropagation(); editFavorite(f.phone); } }),
        h('span', { class: 'fav-del-btn', title: 'إزالة', text: '×', onclick: function (e) { e.stopPropagation(); removeFavorite(f.phone); } })));
    });
  }

  function addCurrentToFavorites() {
    var phone = $('phone').value.trim();
    if (!validPhone(phone)) { toast('خطأ: رقم الجوال يجب أن يتكون من 10 أرقام ويبدأ بـ 05!'); return; }
    var existing = S.d.favorites.filter(function (f) { return f.phone === phone; })[0];
    askText('حفظ في المفضلة', 'أدخل اسمًا لتمييز هذا الرقم', existing ? existing.name : '', 'حفظ').then(function (v) {
      if (v === null) return;
      var name = v.trim() || phone;
      var type = S.d.ui.type || '1';
      if (existing) { existing.name = name; existing.type = type; toast('تم تحديث بيانات "' + name + '" ⭐'); }
      else { S.d.favorites.push({ name: name, phone: phone, type: type, uses: 1 }); toast('تم حفظ "' + name + '" في المفضلة ⭐'); }
      S.save(); renderFavorites(); detectName(phone);
    });
  }
  function editFavorite(phone) {
    var f = S.d.favorites.filter(function (x) { return x.phone === phone; })[0];
    if (!f) return;
    askText('تعديل المفضلة', 'اسم الرقم', f.name, 'حفظ').then(function (v) {
      if (v === null || !v.trim()) return;
      f.name = v.trim(); S.save(); renderFavorites(); detectName($('phone').value); toast('تم تحديث الاسم');
    });
  }
  function removeFavorite(phone) {
    S.d.favorites = S.d.favorites.filter(function (x) { return x.phone !== phone; });
    S.save(); renderFavorites(); detectName($('phone').value); toast('تمت الإزالة من المفضلة');
  }
  function useFavorite(phone) {
    var f = S.d.favorites.filter(function (x) { return x.phone === phone; })[0];
    $('phone').value = phone;
    if (f) { setType(f.type === '2' ? '2' : '1'); f.uses = (f.uses || 0) + 1; S.save(); renderFavorites(); }
    updateCode(); detectName(phone);
    $('amount').focus();
    toast('تم اختيار الرقم');
  }

  // ---------- كلمة السر المحفوظة ----------

  async function onSavePinToggle() {
    var cb = $('savePinCheckbox');
    var prov = currentProv(), acc = currentAccount();
    var key = pinKeyFor(prov, acc);
    if (!cb.checked) { N.pin.remove(key); ui.hasSavedPin = false; updatePinState(); toast('تم حذف كلمة السر المحفوظة'); return; }
    var pin = $('pin').value.trim();
    if (!/^\d{4}$/.test(pin)) { toast('أدخل كلمة السر (4 أرقام) أولًا ثم فعّل الحفظ'); cb.checked = false; return; }
    var a = await N.auth('حفظ كلمة السر', 'سيتم تشفيرها بمفتاح محمي في الجهاز');
    if (!a.ok) { toast('تم إلغاء التحقق، لم تُحفظ كلمة السر'); cb.checked = false; return; }
    var r = N.pin.save(key, pin);
    if (r.ok) { $('pin').value = ''; ui.hasSavedPin = true; toast('تم حفظ كلمة السر مشفرة'); }
    else {
      cb.checked = false;
      toast(r.reason === 'no_lock' ? 'فعّل قفل شاشة على الجهاز أولًا' : 'تعذر حفظ كلمة السر بأمان على هذا الجهاز');
    }
    updatePinState(); updateCode();
  }

  // ---------- تنفيذ التحويل ----------

  function ussdFailText(ev) {
    switch (ev.status) {
      case 'failed':
        return ev.detail === 'USSD_ERROR_SERVICE_UNAVAIL'
          ? 'الخدمة غير متاحة الآن (تحقق من التغطية وأن الشريحة جاهزة)'
          : 'رفضت الشبكة الطلب أو لم تدعمه';
      case 'timeout': return 'لم يصل رد من الشبكة في الوقت المحدد';
      case 'unsupported': return 'جهازك لا يدعم التنفيذ الداخلي (يتطلب Android 8 فما فوق)';
      case 'no_permission': return 'صلاحية الاتصال غير ممنوحة';
      default: return 'تعذر إرسال الطلب من التطبيق';
    }
  }

  function validateTransfer(prov, f) {
    if (prov.needsPhone && !validPhone(f.phone)) return 'خطأ: رقم الجوال يجب أن يتكون من 10 أرقام ويبدأ بـ 05!';
    if (prov.needsAmount) {
      if (!/^\d+(\.\d{1,2})?$/.test(f.amount) || !(parseFloat(f.amount) > 0)) return 'خطأ: قيمة المبلغ يجب أن تكون أكبر من صفر (حتى منزلتين عشريتين)!';
    }
    if (prov.needsPin) {
      if (f.pin && !/^\d{4}$/.test(f.pin)) return 'خطأ: كلمة المرور يجب أن تكون 4 أرقام دقيقة!';
      if (!f.pin && !ui.hasSavedPin) return 'خطأ: كلمة المرور يجب أن تكون 4 أرقام دقيقة!';
    }
    return '';
  }

  function findDuplicate(prov, f) {
    var now = Date.now();
    return S.d.history.filter(function (e) {
      return e.kind === 'transfer' && e.service === prov.service && (e.network || null) === (prov.network || null) &&
        e.phone === f.phone && e.amount === parseFloat(f.amount) && e.status !== 'failed' && (now - e.ts) < 3 * 60000;
    })[0] || null;
  }

  function reviewSheet(prov, acc, f, em, dup) {
    return new Promise(function (resolve) {
      var done = false;
      function fin(v) { if (done) return; done = true; closeSheet(); resolve(v); }
      var name = savedNameFor(f.phone);
      openSheet(function () {
        var root = h('div', {}, h('h2', { text: prov.kind === 'login' ? 'مراجعة الدخول للخدمة' : 'مراجعة التحويل' }));
        if (prov.needsAmount) root.appendChild(h('div', { class: 'review-amount', text: money(parseFloat(f.amount)) }));
        function row(k, v) { root.appendChild(h('div', { class: 'review-row' }, h('span', { text: k }), h('span', { text: v }))); }
        row('الخدمة', prov.label + (prov.netLabel ? ' (' + prov.netLabel + ')' : ''));
        row('الحساب', acc ? accountLabel(acc) : 'غير محدد');
        if (acc) { var s = simOf(acc); if (s) row('الشريحة', simName(s)); }
        if (prov.needsPhone) {
          row('المستفيد', (name ? name + ' - ' : '') + f.phone);
          if (prov.hasType) row('نوع الحساب', f.type === '2' ? 'تاجر' : 'شخص');
        }
        row('طريقة التنفيذ', em.mode === 'inapp' ? 'داخل التطبيق (النتيجة من رد الشبكة)' : 'عبر تطبيق الاتصال');
        if (em.mode === 'dialer') {
          root.appendChild(h('div', { class: 'warn-box', text: 'سيُفتح تطبيق الاتصال لتنفيذ الكود (' + em.why + '). لن تُسجَّل العملية ناجحة إلا بعد أن تؤكدها بنفسك.' }));
        }
        if (dup) {
          root.appendChild(h('div', { class: 'warn-box', text: 'عملية مماثلة (نفس الرقم والمبلغ) أُرسلت ' + ago(dup.ts) + ' وحالتها "' + (STATUS_LABEL[dup.status] || dup.status) + '". تأكد من الرصيد أو رسالة الخدمة قبل التكرار حتى لا يُحوَّل المبلغ مرتين.' }));
        }
        root.appendChild(h('div', { class: 'btn-row' },
          h('button', { class: 'btn', text: dup ? 'إرسال رغم ذلك' : (prov.kind === 'login' ? 'تأكيد' : 'تأكيد وتحويل'), onclick: function () { fin(true); } }),
          h('button', { class: 'btn sec', text: 'إلغاء', onclick: function () { fin(false); } })));
        return root;
      });
    });
  }

  var STAGES = ['التحقق من الهوية', 'إرسال الطلب', 'انتظار رد الشبكة', 'النتيجة'];
  function progressSheet() {
    var items = [];
    var holder = h('div', {});
    var list = h('ul', { class: 'stages' });
    STAGES.forEach(function (t) {
      var li = h('li', {}, h('span', { class: 'stage-ic', text: '○' }), h('span', { text: t }));
      items.push(li); list.appendChild(li);
    });
    holder.appendChild(h('h2', { text: 'جارٍ التنفيذ' }));
    holder.appendChild(list);
    holder.appendChild(h('p', { text: 'لا تغلق التطبيق. النتيجة تُسجَّل بحسب رد الشبكة فقط.' }));
    openSheet(function () { return holder; }, { locked: true });
    function set(n, bad) {
      items.forEach(function (li, i) {
        var ic = li.firstChild;
        if (i < n) { li.className = 'done'; ic.textContent = '✓'; }
        else if (i === n) { li.className = bad ? 'bad' : 'cur'; ic.textContent = bad ? '✕' : ''; if (!bad) { clear(ic); ic.appendChild(h('span', { class: 'spinner', style: 'width:14px;height:14px;border-width:2px' })); } }
        else { li.className = ''; ic.textContent = '○'; }
      });
    }
    return { set: set };
  }

  function resultSheet(entry, prov, acc, ev) {
    var icon = { success: '✅', failed: '❌', unconfirmed: '❔', pending: '⏳' }[entry.status];
    var title = { success: 'تمت العملية', failed: 'لم تنجح العملية', unconfirmed: 'النتيجة غير مؤكدة', pending: 'قيد المعالجة' }[entry.status];
    var msg = '';
    if (entry.status === 'success') msg = 'ردّ الشبكة يدل على نجاح العملية. راجع النص الأصلي أدناه.';
    else if (entry.status === 'failed') msg = entry.notSent ? ussdFailText(ev) + '. لم يُرسل الطلب إلى الخدمة، لذلك لم يُخصم شيء.' : (ev.status === 'response' ? 'ردّ الشبكة يدل على فشل العملية.' : ussdFailText(ev));
    else if (ev.status === 'timeout') msg = 'لم يصل رد من الشبكة. قد تكون العملية نُفذت: تحقق من رسالة الخدمة أو رصيدك قبل أي محاولة جديدة.';
    else msg = 'لا يمكن الجزم من نص الرد. تحقق من رسالة الخدمة أو رصيدك ثم أكّد النتيجة بنفسك.';
    openSheet(function () {
      var root = h('div', {},
        h('div', { class: 'big-status' }, h('div', { class: 'ic', text: icon }), h('div', { class: 'tt', text: title })),
        h('p', { text: msg }));
      if (entry.reference) root.appendChild(h('div', { class: 'review-row' }, h('span', { text: 'الرقم المرجعي' }), h('span', { text: entry.reference })));
      if (entry.amount) root.appendChild(h('div', { class: 'review-row' }, h('span', { text: 'المبلغ' }), h('span', { text: money(entry.amount) })));
      if (entry.response) {
        root.appendChild(h('div', { class: 'hint', text: 'نص رد الشبكة كما وصل:' }));
        root.appendChild(h('div', { class: 'resp', text: entry.response }));
      }
      var row = h('div', { class: 'btn-row' });
      if (entry.status === 'unconfirmed') {
        row.appendChild(h('button', { class: 'btn', text: 'نجحت', onclick: function () { setManual(entry.id, 'success'); closeSheet(); } }));
        row.appendChild(h('button', { class: 'btn danger', text: 'فشلت', onclick: function () { setManual(entry.id, 'failed'); closeSheet(); } }));
      }
      if (entry.status === 'success' && prov.balanceCode && acc) {
        row.appendChild(h('button', { class: 'btn sec', text: 'تحديث الرصيد', onclick: function () { closeSheet(); showTab('balance'); refreshBalance(acc); } }));
      }
      row.appendChild(h('button', { class: 'btn sec', text: 'إغلاق', onclick: closeSheet }));
      root.appendChild(row);
      return root;
    });
  }

  function setManual(id, status) {
    S.updateHistory(id, { status: status, manual: true });
    refreshAll();
    toast(status === 'success' ? 'سُجّلت العملية ناجحة بتأكيدك' : 'سُجّلت العملية فاشلة بتأكيدك');
  }

  async function startTransfer() {
    if (ui.busy) { toast('هناك عملية قيد التنفيذ، انتظر انتهاءها'); return; }
    var prov = currentProv(), acc = currentAccount();
    var f = formValues();
    var err = validateTransfer(prov, f);
    if (err) { toast(err); return; }

    var em = execMode(prov);
    if (em.mode === 'inapp') {
      var g = simGuard(acc);
      if (g) { toast(g); return; }
    }

    var dup = prov.kind === 'transfer' ? findDuplicate(prov, f) : null;
    var ok = await reviewSheet(prov, acc, f, em, dup);
    if (!ok) return;

    var usingSaved = prov.needsPin && !f.pin;
    var pin = f.pin;
    if (N.available && (S.d.settings.requireAuth || usingSaved)) {
      var a = await N.auth(prov.kind === 'login' ? 'تأكيد الدخول' : 'تأكيد التحويل', prov.kind === 'login' ? prov.label : (money(parseFloat(f.amount)) + ' إلى ' + f.phone));
      if (!a.ok && a.reason !== 'no_lock') { toast('تم إلغاء التحقق، لم تُنفَّذ العملية'); return; }
      if (a.reason === 'no_lock') {
        if (usingSaved) { toast('جهازك بلا قفل شاشة: أدخل كلمة السر يدويًا'); return; }
        toast('تنبيه: جهازك بلا قفل شاشة، لا يمكن التحقق بالبصمة');
      }
    }
    if (usingSaved) {
      var r = N.pin.get(pinKeyFor(prov, acc));
      if (!r.ok) { toast(r.reason === 'auth_required' ? 'انتهت صلاحية التحقق، أعد المحاولة' : 'تعذر قراءة كلمة السر المحفوظة، أدخلها يدويًا'); updatePinState(); return; }
      pin = r.pin;
    }

    var code = P.buildCode(prov, { type: f.type, phone: f.phone, amount: f.amount, pin: pin });
    var now = new Date();
    var entry = S.addHistory({
      id: S.uid(), ts: now.getTime(), dateStr: S.localDateStr(now), kind: prov.kind,
      accountId: acc ? acc.id : null, service: prov.service, network: prov.network,
      typeCode: f.type, phone: prov.needsPhone ? f.phone : '', name: savedNameFor(f.phone) || '',
      amount: prov.needsAmount ? parseFloat(f.amount) : 0,
      status: em.mode === 'inapp' ? 'pending' : 'unconfirmed', mode: em.mode,
      reference: null, response: '', detail: '', code: P.previewCode(prov, { type: f.type, phone: f.phone, amount: f.amount, pin: pin })
    });
    S.flush();
    refreshAll();

    if (em.mode === 'dialer') {
      N.dialer(code);
      toast(prov.kind === 'login' ? 'فُتح تطبيق الاتصال' : 'فُتح تطبيق الاتصال: العملية غير مؤكدة حتى تؤكدها');
      return;
    }

    ui.busy = true;
    var pg = progressSheet();
    pg.set(1);
    var ev;
    try {
      var evP = N.ussd(code, acc ? acc.subId : null);
      pg.set(2);
      ev = await evP;
    } catch (e) {
      ev = { status: 'error', detail: 'exception' };
    }
    code = null; pin = null;
    ui.busy = false;

    var patch = { elapsedMs: ev.elapsedMs };
    if (ev.status === 'response') {
      var c = P.classifyTransfer(ev.response);
      patch.status = c.status; patch.response = String(ev.response).slice(0, 1000);
      patch.reference = c.ref; patch.detail = c.why;
    } else if (ev.status === 'failed') {
      patch.status = 'failed'; patch.detail = ev.detail;
    } else if (ev.status === 'timeout') {
      patch.status = 'unconfirmed'; patch.detail = 'timeout';
    } else {
      patch.status = 'failed'; patch.detail = ev.status + ':' + (ev.detail || ''); patch.notSent = true;
    }
    entry = S.updateHistory(entry.id, patch);
    S.flush();
    $('pin').value = '';
    updateCode();
    refreshAll();
    resultSheet(entry, prov, acc, ev);
  }

  // بعد العودة من تطبيق الاتصال: نسأل المستخدم عن نتيجة آخر عملية غير مؤكدة
  function askAboutDialerEntry() {
    if (ui.sheetOpen || ui.locked) return;
    var cutoff = Date.now() - 15 * 60000;
    var e = S.d.history.filter(function (x) {
      return x.mode === 'dialer' && x.status === 'unconfirmed' && x.kind === 'transfer' && !x.asked && !x.legacy && x.ts > cutoff;
    })[0];
    if (!e) return;
    S.updateHistory(e.id, { asked: true });
    openSheet(function () {
      return h('div', {},
        h('h2', { text: 'ما نتيجة العملية؟' }),
        h('p', { text: 'نفّذت تحويل ' + money(e.amount) + ' إلى ' + (e.name ? e.name + ' - ' : '') + e.phone + ' عبر تطبيق الاتصال. التطبيق لا يعرف نتيجتها. أكّدها بحسب رسالة الخدمة التي وصلتك.' }),
        h('div', { class: 'btn-row' },
          h('button', { class: 'btn', text: 'نجحت', onclick: function () { setManual(e.id, 'success'); closeSheet(); } }),
          h('button', { class: 'btn danger', text: 'فشلت', onclick: function () { setManual(e.id, 'failed'); closeSheet(); } }),
          h('button', { class: 'btn sec', text: 'لاحقًا', onclick: closeSheet })));
    });
  }

  // ---------- تبويب الرصيد ----------

  function balanceFailText(ev) {
    return ussdFailText(ev);
  }

  async function refreshBalance(acc) {
    var prov = provOfAccount(acc);
    if (!prov.balanceCode) return;
    var em = execMode(prov);
    // الرصيد لا يحتاج خطوات تفاعلية في Jawwal Pay، لكن يلزم أن يكون التنفيذ الداخلي متاحًا
    var canInApp = N.available && S.d.settings.inApp && ui.device.ussdApiSupported && ui.perms.call;
    if (!canInApp) {
      N.dialer(prov.balanceCode);
      toast('فُتح تطبيق الاتصال: الرصيد يظهر هناك ولا يُحفظ في التطبيق');
      return;
    }
    if (ui.busy) { toast('هناك عملية قيد التنفيذ، انتظر انتهاءها'); return; }
    var g = simGuard(acc);
    if (g) { toast(g); return; }

    ui.busy = true;
    ui.balLoading[acc.id] = true;
    ui.balErr[acc.id] = null;
    renderBalance();
    var ev;
    try { ev = await N.ussd(prov.balanceCode, acc.subId); }
    catch (e) { ev = { status: 'error', detail: 'exception' }; }
    ui.busy = false;
    ui.balLoading[acc.id] = false;

    if (ev.status === 'response') {
      var raw = String(ev.response).slice(0, 1000);
      var menu = P.isMenu(raw);
      var v = menu ? null : P.parseBalance(raw);
      if (v != null) {
        acc.balance = { amount: v, at: Date.now(), raw: raw };
      } else {
        ui.balErr[acc.id] = {
          text: menu ? 'ردّ الشبكة قائمة تفاعلية، ولا يمكن قراءة الرصيد منها داخل التطبيق.' : 'تعذر تحديد الرصيد من نص الرد.',
          raw: raw, at: Date.now()
        };
      }
    } else {
      ui.balErr[acc.id] = { text: balanceFailText(ev), raw: '', at: Date.now() };
    }
    S.save();
    renderBalance();
    renderStatsBits();
  }

  function renderBalance() {
    var root = $('view-balance');
    clear(root);
    var accs = S.d.accounts;
    if (!accs.length) {
      root.appendChild(h('div', { class: 'card' },
        h('div', { class: 'empty', text: 'لا توجد حسابات بعد. أضف حسابًا لعرض رصيده.' }),
        h('div', { class: 'btn-row' }, h('button', { class: 'btn', text: 'إضافة حساب', onclick: function () { showTab('accounts'); openAccountSheet(null); } }))));
      return;
    }
    accs.forEach(function (a) {
      var prov = provOfAccount(a);
      var st = accountStatus(a);
      var card = h('div', { class: 'card' });
      card.appendChild(h('div', { class: 'acc-head' },
        h('div', {},
          h('div', { class: 'acc-title', text: accountLabel(a) }),
          h('div', { class: 'acc-sub' }, h('span', { class: 'service-badge ' + prov.badge, text: prov.label }), a.phone ? ' ' + a.phone : '')),
        prov.balanceCode
          ? h('button', { class: 'btn small', text: 'تحديث الرصيد', disabled: ui.balLoading[a.id] || ui.busy, onclick: function () { refreshBalance(a); } })
          : null));
      if (!prov.balanceCode) {
        card.appendChild(h('div', { class: 'hint', text: 'لا توجد قناة رسمية مدعومة للاستعلام عن رصيد هذه الخدمة من داخل التطبيق، لذلك لا يُعرض رصيد لها.' }));
      } else if (ui.balLoading[a.id]) {
        card.appendChild(h('div', { style: 'margin:14px 0' }, h('span', { class: 'spinner' }), ' جارٍ جلب الرصيد من الشبكة...'));
      } else {
        if (a.balance) {
          card.appendChild(h('div', { class: 'bal-amount', text: money(a.balance.amount) }));
          var old = Date.now() - a.balance.at > 3600000;
          card.appendChild(h('div', { class: 'bal-meta', text: 'آخر تحديث: ' + timeStr(a.balance.at) + (old ? ' (قديم، حدّثه للتأكد)' : '') }));
        } else {
          card.appendChild(h('div', { class: 'bal-amount none', text: '— لا يوجد رصيد محدّث' }));
        }
        var er = ui.balErr[a.id];
        if (er) {
          card.appendChild(h('div', { class: 'err-text', text: er.text }));
          if (er.raw) {
            card.appendChild(h('div', { class: 'hint', text: 'نص رد الشبكة كما وصل:' }));
            card.appendChild(h('div', { class: 'resp', text: er.raw }));
          }
        }
      }
      card.appendChild(h('div', { class: 'acc-sub' }, h('span', { class: 'dot ' + st.cls }), st.text));
      root.appendChild(card);
    });
    root.appendChild(h('div', { class: 'hint', style: 'color:#fff;padding:0 4px', text: 'الرصيد يُعرض فقط إذا استُخرج من ردّ الشبكة الفعلي. لا تُعرض قيم تقديرية.' }));
  }

  async function homeBalanceClick() {
    var prov = currentProv();
    if (!prov.balanceCode) return;
    var canInApp = N.available && S.d.settings.inApp && ui.device.ussdApiSupported && ui.perms.call;
    if (!canInApp) { N.dialer(prov.balanceCode); toast('فُتح تطبيق الاتصال'); return; }
    var acc = currentAccount();
    if (!acc) {
      var yes = await askConfirm('لا يوجد حساب', 'لعرض الرصيد داخل التطبيق أضف حسابًا لـ ' + prov.label + ' واربطه بشريحته. هل تريد إضافته الآن؟', 'إضافة حساب');
      if (yes) { showTab('accounts'); openAccountSheet(null, prov); }
      return;
    }
    showTab('balance');
    refreshBalance(acc);
  }

  // ---------- تبويب العمليات ----------

  function transferEntries() { return S.d.history.filter(function (e) { return e.kind === 'transfer'; }); }
  function sumOk(list) { return list.reduce(function (s, e) { return s + (e.amount || 0); }, 0); }
  function okList() { return transferEntries().filter(function (e) { return e.status === 'success' && !e.legacy; }); }

  function renderStatsBits() {
    var today = S.localDateStr(new Date()), month = today.slice(0, 7);
    var ok = okList();
    $('statDay').textContent = money(sumOk(ok.filter(function (e) { return e.dateStr === today; })));
    $('statMonth').textContent = money(sumOk(ok.filter(function (e) { return (e.dateStr || '').indexOf(month) === 0; })));
  }

  var SERVICE_FILTERS = [['all', 'كل الخدمات'], ['jawwal:jawwal', 'Jawwal Pay'], ['jawwal:ooredoo', 'Ooredoo'], ['palpay', 'PalPay'], ['bop', 'بنك فلسطين']];
  var STATUS_FILTERS = [['all', 'الكل'], ['success', 'ناجحة'], ['failed', 'فاشلة'], ['pending', 'قيد المعالجة'], ['unconfirmed', 'غير مؤكدة']];

  function entryKey(e) { return e.service === 'jawwal' ? 'jawwal:' + (e.network || 'jawwal') : e.service; }

  function renderOps() {
    var root = $('view-ops');
    clear(root);
    var today = S.localDateStr(new Date()), month = today.slice(0, 7);
    var all = transferEntries(), ok = okList();
    var okToday = ok.filter(function (e) { return e.dateStr === today; });
    var okMonth = ok.filter(function (e) { return (e.dateStr || '').indexOf(month) === 0; });

    // لوحة المعلومات
    var dash = h('div', { class: 'card' }, h('h2', { text: 'لوحة المعلومات المالية' }));
    dash.appendChild(h('div', { class: 'stat-grid' },
      statBox('تحويلات اليوم (ناجحة)', money(sumOk(okToday))),
      statBox('تحويلات الشهر (ناجحة)', money(sumOk(okMonth))),
      statBox('عدد العمليات الناجحة', String(ok.length)),
      statBox('إجمالي المحوّل بنجاح', money(sumOk(ok)))));
    dash.appendChild(h('div', { class: 'hint', text: 'تُحتسب العمليات الناجحة فقط (بردّ الشبكة أو بتأكيدك اليدوي). الفاشلة وغير المؤكدة لا تدخل في المبالغ.' }));

    var dist = h('div', { style: 'margin-top:10px' }, h('h3', { text: 'توزيع عمليات الشهر حسب الخدمة' }));
    var max = 0, rows = [];
    SERVICE_FILTERS.slice(1).forEach(function (sf) {
      var l = okMonth.filter(function (e) { return entryKey(e) === sf[0]; });
      var amt = sumOk(l);
      if (amt > max) max = amt;
      rows.push({ key: sf[0], label: sf[1], count: l.length, amt: amt });
    });
    if (!okMonth.length) dist.appendChild(h('div', { class: 'empty', text: 'لا توجد عمليات ناجحة هذا الشهر' }));
    rows.forEach(function (r) {
      if (!r.count) return;
      var color = P.DEFS[r.key].color;
      dist.appendChild(h('div', { class: 'bar-row' },
        h('span', { class: 'name', text: r.label }),
        h('div', { class: 'bar-track' }, h('div', { class: 'bar-fill', style: 'width:' + Math.max(4, Math.round(r.amt / (max || 1) * 100)) + '%;background:' + color })),
        h('span', { class: 'num', text: r.count + ' · ' + money(r.amt) })));
    });
    dash.appendChild(dist);

    var bals = h('div', { style: 'margin-top:10px' }, h('h3', { text: 'الرصيد المتاح لكل حساب (آخر قيمة معروفة)' }));
    if (!S.d.accounts.length) bals.appendChild(h('div', { class: 'hint', text: 'لا توجد حسابات.' }));
    S.d.accounts.forEach(function (a) {
      var p = provOfAccount(a);
      bals.appendChild(h('div', { class: 'review-row' },
        h('span', { text: accountLabel(a) }),
        h('span', { text: !p.balanceCode ? 'غير مدعوم رسميًا' : (a.balance ? money(a.balance.amount) + ' · ' + ago(a.balance.at) : 'لم يُجلب بعد') })));
    });
    dash.appendChild(bals);
    root.appendChild(dash);

    // قائمة العمليات
    var counts = {};
    all.forEach(function (e) { counts[e.status] = (counts[e.status] || 0) + 1; });
    var card = h('div', { class: 'card' },
      h('h2', { text: 'سجل العمليات' }));
    var search = h('input', { class: 'search-input', type: 'text', placeholder: 'بحث بالاسم أو رقم الهاتف أو الخدمة أو الرقم المرجعي...', 'aria-label': 'بحث' });
    search.value = ui.opsQuery;
    search.addEventListener('input', function () { ui.opsQuery = search.value; renderOpsList(); });
    card.appendChild(search);

    var sp = h('div', { class: 'filter-pills' });
    STATUS_FILTERS.forEach(function (sf) {
      var n = sf[0] === 'all' ? all.length : (counts[sf[0]] || 0);
      sp.appendChild(h('div', { class: 'filter-pill' + (ui.opsStatus === sf[0] ? ' active' : ''), text: sf[1] + ' (' + n + ')', onclick: function () { ui.opsStatus = sf[0]; renderOps(); } }));
    });
    card.appendChild(sp);
    var vp = h('div', { class: 'filter-pills' });
    vp.appendChild(h('div', { class: 'filter-pill' + (ui.opsToday ? ' active' : ''), text: 'اليوم', onclick: function () { ui.opsToday = !ui.opsToday; renderOps(); } }));
    SERVICE_FILTERS.forEach(function (sf) {
      vp.appendChild(h('div', { class: 'filter-pill' + (ui.opsService === sf[0] ? ' active' : ''), text: sf[1], onclick: function () { ui.opsService = sf[0]; renderOps(); } }));
    });
    card.appendChild(vp);
    card.appendChild(h('div', { id: 'opsList' }));
    root.appendChild(card);
    renderOpsList();
  }

  function statBox(label, val) {
    return h('div', { class: 'stat-box' }, h('div', { class: 'lbl', text: label }), h('div', { class: 'val', text: val }));
  }

  function renderOpsList() {
    var list = $('opsList');
    if (!list) return;
    clear(list);
    var today = S.localDateStr(new Date());
    var q = ui.opsQuery.trim().toLowerCase();
    var items = S.d.history.filter(function (e) {
      if (ui.opsStatus !== 'all' && e.status !== ui.opsStatus) return false;
      if (ui.opsService !== 'all' && entryKey(e) !== ui.opsService) return false;
      if (ui.opsToday && e.dateStr !== today) return false;
      if (q) {
        var hay = [e.phone, P.get(e.service, e.network).label, e.name, e.reference].join(' ').toLowerCase();
        if (hay.indexOf(q) < 0) return false;
      }
      return true;
    });
    if (!items.length) { list.appendChild(h('div', { class: 'empty', text: 'لا توجد سجلات مطابقة' })); return; }
    items.slice(0, 150).forEach(function (e) { list.appendChild(opsItem(e)); });
    if (items.length > 150) list.appendChild(h('div', { class: 'hint', text: 'تُعرض أحدث 150 عملية. استخدم البحث للوصول لغيرها.' }));
  }

  function opsItem(e) {
    var prov = P.get(e.service, e.network);
    var title = e.kind === 'login' ? 'دخول إلى خدمة البنك' : (e.name ? e.name + ' (' + e.phone + ')' : e.phone);
    var box = h('div', { class: 'history-item' });
    var row = h('div', { class: 'row1', onclick: function () { ui.expanded[e.id] = !ui.expanded[e.id]; renderOpsList(); } },
      h('div', {},
        h('strong', { text: title }),
        h('div', { class: 'history-time' },
          h('span', { class: 'service-badge ' + prov.badge, text: prov.label }), ' ', statusTag(e), ' ',
          e.kind === 'login' ? '' : (e.typeCode === '2' ? 'تاجر' : 'شخص'), ' | ', timeStr(e.ts))),
      h('span', { class: 'history-amount', text: e.amount ? money(e.amount) : '' }));
    box.appendChild(row);
    if (ui.expanded[e.id]) {
      var d = h('div', { class: 'detail-box' });
      function kv(k, v) { if (v == null || v === '') return; d.appendChild(h('div', { class: 'kv' }, h('span', { text: k }), h('span', { text: String(v) }))); }
      kv('الحالة', STATUS_LABEL[e.status] + (e.manual ? ' (بتأكيد يدوي)' : ''));
      kv('طريقة التنفيذ', e.mode === 'inapp' ? 'داخل التطبيق' : 'عبر تطبيق الاتصال');
      kv('الرقم المرجعي', e.reference);
      kv('الكود (مقنّع)', e.code);
      kv('مدة الاستجابة', e.elapsedMs != null ? e.elapsedMs + ' ms' : '');
      if (e.legacy) kv('ملاحظة', 'سجل من النسخة القديمة: لم تُعرف نتيجته ولا يدخل في الإجماليات');
      if (e.response) { d.appendChild(h('div', { class: 'hint', text: 'نص رد الشبكة كما وصل:' })); d.appendChild(h('div', { class: 'resp', text: e.response })); }
      var acts = h('div', { class: 'btn-row' });
      if (e.status === 'unconfirmed' || e.status === 'pending') {
        acts.appendChild(h('button', { class: 'btn small', text: 'تأكيد: نجحت', onclick: function () { setManual(e.id, 'success'); } }));
        acts.appendChild(h('button', { class: 'btn small danger', text: 'تأكيد: فشلت', onclick: function () { setManual(e.id, 'failed'); } }));
      }
      if (e.kind === 'transfer') acts.appendChild(h('button', { class: 'btn small sec', text: '🔄 تحويل مرة أخرى', onclick: function () { resendEntry(e.id); } }));
      acts.appendChild(h('button', { class: 'btn small sec', text: 'حذف', onclick: function () { deleteEntry(e.id); } }));
      d.appendChild(acts);
      box.appendChild(d);
    }
    return box;
  }

  function resendEntry(id) {
    var e = S.d.history.filter(function (x) { return x.id === id; })[0];
    if (!e) return;
    S.d.ui.network = e.network || S.d.ui.network;
    setService(e.service);
    if (e.service === 'jawwal' && e.network) setNetwork(e.network);
    if (e.typeCode) setType(e.typeCode);
    if (e.phone) { $('phone').value = e.phone; detectName(e.phone); }
    if (e.amount) $('amount').value = String(e.amount);
    updateCode();
    showTab('home');
    window.scrollTo(0, 0);
    toast('تمت تعبئة بيانات العملية السابقة 🔄');
  }

  async function deleteEntry(id) {
    var yes = await askConfirm('حذف العملية', 'سيُحذف هذا السجل من الجهاز. هل أنت متأكد؟', 'حذف', true);
    if (!yes) return;
    S.deleteHistory(id); refreshAll(); toast('تم حذف العملية');
  }

  // ---------- تبويب الحسابات والإعدادات ----------

  var ACC_TYPES = [
    ['jawwal:jawwal', 'Jawwal Pay (شبكة جوال)'],
    ['jawwal:ooredoo', 'Jawwal Pay (شبكة أوريدو/وطنية)'],
    ['palpay', 'PalPay'],
    ['bop', 'بنك فلسطين (BOP)']
  ];

  function openAccountSheet(acc, presetProv) {
    var type0 = acc ? (acc.service === 'jawwal' ? 'jawwal:' + acc.network : acc.service)
                    : (presetProv ? presetProv.key : 'jawwal:jawwal');
    openSheet(function () {
      var name = h('input', { class: 'field', type: 'text', 'aria-label': 'اسم الحساب', placeholder: 'مثال: حسابي الشخصي' });
      name.value = acc ? acc.name || '' : '';
      var type = h('select', { class: 'field', 'aria-label': 'الخدمة' });
      ACC_TYPES.forEach(function (t) { var o = h('option', { value: t[0], text: t[1] }); if (t[0] === type0) o.selected = true; type.appendChild(o); });
      var phone = h('input', { class: 'field', type: 'tel', inputmode: 'numeric', 'aria-label': 'رقم الخط', placeholder: '05XXXXXXXX (اختياري)', style: 'direction:ltr;text-align:left' });
      phone.value = acc ? acc.phone || '' : '';
      var sim = h('select', { class: 'field', 'aria-label': 'الشريحة' });
      sim.appendChild(h('option', { value: '', text: ui.sims.length > 1 ? 'غير محدد (اختر شريحة)' : 'الشريحة الافتراضية' }));
      ui.sims.forEach(function (s) {
        var o = h('option', { value: String(s.subId), text: simName(s) });
        if (acc && acc.subId === s.subId) o.selected = true;
        sim.appendChild(o);
      });
      var def = h('input', { type: 'checkbox', id: 'accDefault' });
      def.checked = acc ? !!acc.isDefault : S.d.accounts.length === 0;
      var err = h('div', { class: 'err-text' });
      var root = h('div', {},
        h('h2', { text: acc ? 'تعديل الحساب' : 'إضافة حساب' }),
        h('label', { class: 'f', text: 'اسم الحساب' }), name,
        h('label', { class: 'f', text: 'الخدمة' }), type,
        h('label', { class: 'f', text: 'رقم الخط المرتبط' }), phone,
        h('label', { class: 'f', text: 'الشريحة في هذا الجهاز' }), sim,
        h('div', { class: 'hint', text: ui.perms.phoneState || !N.available ? 'اختيار الشريحة يضمن تنفيذ العملية على الخط الصحيح في الأجهزة ثنائية الشريحة.' : 'امنح صلاحية حالة الهاتف من هذا التبويب لتظهر الشرائح هنا.' }),
        h('div', { class: 'checkbox-group', style: 'margin-top:10px' }, h('div', {}, def, h('label', { for: 'accDefault', text: 'الحساب الافتراضي لهذه الخدمة' }))),
        err,
        h('div', { class: 'btn-row' },
          h('button', { class: 'btn', text: 'حفظ', onclick: function () {
            var p = cleanPhone(phone.value);
            if (p && !validPhone(p)) { err.textContent = 'رقم الخط يجب أن يتكون من 10 أرقام ويبدأ بـ 05'; return; }
            var parts = type.value.split(':');
            var svc = parts[0], net = parts[1] || null;
            var prov = P.get(svc, net);
            var o = acc || { id: S.uid(), balance: null };
            o.name = name.value.trim() || prov.label;
            o.service = svc; o.network = svc === 'jawwal' ? net : null;
            o.phone = p;
            o.subId = sim.value === '' ? null : parseInt(sim.value, 10);
            o.isDefault = def.checked;
            if (!acc) S.d.accounts.push(o);
            if (o.isDefault) S.d.accounts.forEach(function (x) { if (x !== o && x.service === o.service && x.network === o.network) x.isDefault = false; });
            S.d.ui.accountId = o.id;
            S.save(); closeSheet(); refreshAll(); toast('تم حفظ الحساب');
          } }),
          h('button', { class: 'btn sec', text: 'إلغاء', onclick: closeSheet })));
      return root;
    });
  }

  async function deleteAccount(a) {
    var yes = await askConfirm('حذف الحساب', 'سيُحذف الحساب "' + accountLabel(a) + '" وكلمة السر المحفوظة له (إن وجدت). سجل العمليات يبقى. هل أنت متأكد؟', 'حذف', true);
    if (!yes) return;
    N.pin.remove('acc_' + a.id);
    S.d.accounts = S.d.accounts.filter(function (x) { return x.id !== a.id; });
    syncAccount(); S.save(); refreshAll(); toast('تم حذف الحساب');
  }

  function detectAccountsFromSims() {
    if (!ui.sims.length) { toast('لا توجد شرائح مقروءة. امنح صلاحية حالة الهاتف أولًا'); return; }
    var added = 0;
    ui.sims.forEach(function (s) {
      var mnc = parseInt(s.mnc, 10);
      if (String(s.mcc) !== '425' || (mnc !== 5 && mnc !== 6)) return;
      var net = mnc === 5 ? 'jawwal' : 'ooredoo';
      if (S.d.accounts.some(function (a) { return a.service === 'jawwal' && a.network === net && a.subId === s.subId; })) return;
      S.d.accounts.push({
        id: S.uid(), name: 'Jawwal Pay - ' + (net === 'jawwal' ? 'جوال' : 'وطنية'), service: 'jawwal', network: net,
        phone: '', subId: s.subId, isDefault: !S.d.accounts.some(function (a) { return a.service === 'jawwal' && a.network === net && a.isDefault; }), balance: null
      });
      added++;
    });
    syncAccount(); S.save(); refreshAll();
    toast(added ? 'أُضيف ' + added + ' حساب من الشرائح. عدّل الاسم ورقم الخط إن أردت' : 'لم يُتعرف على شرائح جوال أو وطنية جديدة');
  }

  function switchRow(title, desc, checked, onchange, disabled) {
    var inp = h('input', { type: 'checkbox', 'aria-label': title });
    inp.checked = !!checked; inp.disabled = !!disabled;
    inp.addEventListener('change', function () { onchange(inp.checked); });
    return h('div', { class: 'set-row' },
      h('div', {}, h('div', { class: 't', text: title }), h('div', { class: 'd', text: desc })),
      h('label', { class: 'switch' }, inp, h('span', { class: 'sl' })));
  }

  function renderAccounts() {
    var root = $('view-accounts');
    clear(root);

    var accCard = h('div', { class: 'card' }, h('h2', { text: 'الحسابات والخدمات' }));
    if (!S.d.accounts.length) accCard.appendChild(h('div', { class: 'empty', text: 'لا توجد حسابات. أضف حسابًا واربطه بالشريحة المناسبة.' }));
    S.d.accounts.forEach(function (a) {
      var prov = provOfAccount(a), st = accountStatus(a);
      var capTxt = prov.inApp ? 'تنفيذ داخلي' : 'عبر تطبيق الاتصال';
      capTxt += prov.balanceCode ? ' + رصيد' : ' · بلا استعلام رصيد';
      accCard.appendChild(h('div', { class: 'history-item' },
        h('div', { class: 'acc-head' },
          h('div', {},
            h('div', { class: 'acc-title', text: (a.isDefault ? '★ ' : '') + accountLabel(a) }),
            h('div', { class: 'acc-sub' }, h('span', { class: 'service-badge ' + prov.badge, text: prov.label }), a.phone ? ' ' + a.phone : ''),
            h('div', { class: 'acc-sub' }, h('span', { class: 'dot ' + st.cls }), st.text),
            h('div', { class: 'acc-sub', text: capTxt }))),
        h('div', { class: 'btn-row' },
          h('button', { class: 'btn small sec', text: 'تعديل', onclick: function () { openAccountSheet(a); } }),
          !a.isDefault ? h('button', { class: 'btn small sec', text: 'تعيين كافتراضي', onclick: function () {
            S.d.accounts.forEach(function (x) { if (x.service === a.service && x.network === a.network) x.isDefault = false; });
            a.isDefault = true; S.save(); refreshAll();
          } }) : null,
          h('button', { class: 'btn small sec', text: 'حذف', onclick: function () { deleteAccount(a); } }))));
    });
    accCard.appendChild(h('div', { class: 'btn-row' },
      h('button', { class: 'btn', text: '+ إضافة حساب', onclick: function () { openAccountSheet(null); } }),
      N.available ? h('button', { class: 'btn sec', text: 'اكتشاف من الشرائح', onclick: function () { refreshDevice(); detectAccountsFromSims(); } }) : null));
    root.appendChild(accCard);

    // الإعدادات
    var set = h('div', { class: 'card' }, h('h2', { text: 'الإعدادات والأمان' }));
    var themeSel = h('select', { class: 'field', style: 'width:auto;padding:6px 10px', 'aria-label': 'المظهر' });
    [['system', 'تلقائي'], ['light', 'فاتح'], ['dark', 'داكن']].forEach(function (t) {
      var o = h('option', { value: t[0], text: t[1] }); if (S.d.settings.theme === t[0]) o.selected = true; themeSel.appendChild(o);
    });
    themeSel.addEventListener('change', function () { S.d.settings.theme = themeSel.value; S.save(); applyTheme(); });
    set.appendChild(h('div', { class: 'set-row' }, h('div', {}, h('div', { class: 't', text: 'المظهر' })), themeSel));

    var inAppAvail = N.available && ui.device.ussdApiSupported;
    set.appendChild(switchRow('التنفيذ داخل التطبيق',
      inAppAvail ? 'تُنفَّذ الأكواد المدعومة وتُعرض نتيجتها هنا بدل فتح تطبيق الاتصال.' : 'غير متاح: يتطلب تطبيق Android 8 فما فوق.',
      S.d.settings.inApp && inAppAvail, function (v) { S.d.settings.inApp = v; S.save(); refreshAll(); }, !inAppAvail));
    set.appendChild(switchRow('التحقق قبل كل تحويل', 'يطلب البصمة أو قفل الجهاز بعد مراجعة التحويل.',
      S.d.settings.requireAuth, function (v) { S.d.settings.requireAuth = v; S.save(); }, !N.available));
    set.appendChild(switchRow('قفل التطبيق عند الفتح', 'يطلب البصمة أو قفل الجهاز عند فتح التطبيق أو العودة إليه بعد دقيقتين.',
      S.d.settings.lockOnOpen, function (v) { S.d.settings.lockOnOpen = v; S.save(); }, !N.available || !ui.device.deviceSecure));
    set.appendChild(switchRow('منع لقطات الشاشة', 'يخفي محتوى التطبيق من لقطات الشاشة ومعاينة التطبيقات الأخيرة.',
      S.d.settings.secureScreen, function (v) { S.d.settings.secureScreen = v; S.save(); N.setSecureScreen(v); }, !N.available));
    root.appendChild(set);

    var perm = h('div', { class: 'card' }, h('h2', { text: 'الصلاحيات والجهاز' }));
    function line(k, v) { perm.appendChild(h('div', { class: 'review-row' }, h('span', { text: k }), h('span', { text: v }))); }
    line('الجهاز', N.available ? (ui.device.model + ' · Android ' + ui.device.release) : 'متصفح');
    line('واجهة USSD الرسمية', ui.device.ussdApiSupported ? 'مدعومة' : 'غير مدعومة');
    line('صلاحية الاتصال', ui.perms.call ? 'ممنوحة' : 'غير ممنوحة');
    line('صلاحية قراءة الشرائح', ui.perms.phoneState ? 'ممنوحة' : 'غير ممنوحة');
    line('قفل شاشة الجهاز', ui.device.deviceSecure ? 'مفعّل' : 'غير مفعّل');
    line('الشرائح المقروءة', String(ui.sims.length));
    if (N.available) {
      perm.appendChild(h('div', { class: 'btn-row' },
        h('button', { class: 'btn small sec', text: 'منح الصلاحيات', onclick: function () { N.requestPermissions(); } }),
        h('button', { class: 'btn small sec', text: 'تحديث', onclick: function () { refreshDevice(); refreshAll(); } })));
    } else {
      perm.appendChild(h('div', { class: 'hint', text: 'في المتصفح تُحفظ البيانات بلا تشفير ولا تعمل ميزات التنفيذ الداخلي. استخدم تطبيق Android.' }));
    }
    root.appendChild(perm);

    var data = h('div', { class: 'card' }, h('h2', { text: 'البيانات' }),
      h('div', { class: 'hint', text: 'النسخة الاحتياطية تحوي الحسابات والمفضلة والسجل، وبدون أي كلمات سر.' }),
      h('div', { class: 'btn-row' },
        h('button', { class: 'btn small sec', text: 'نسخ نسخة احتياطية', onclick: function () {
          if (N.copy(S.exportBackup())) toast('تم النسخ. الصقه في مكان آمن'); else toast('النسخ متاح داخل التطبيق فقط');
        } }),
        h('button', { class: 'btn small sec', text: 'استيراد بيانات', onclick: openImportSheet }),
        N.available ? h('button', { class: 'btn small sec', text: 'أداة التشخيص', onclick: function () { S.flush(); window.location.href = 'diagnostic.html'; } }) : null,
        h('button', { class: 'btn small danger', text: 'مسح كل السجل', onclick: async function () {
          var yes = await askConfirm('مسح السجل', 'سيُمسح سجل العمليات بالكامل من الجهاز. الحسابات والمفضلة تبقى. متأكد؟', 'مسح الكل', true);
          if (yes) { S.clearHistory(); refreshAll(); toast('تم مسح السجل بالكامل'); }
        } })));
    root.appendChild(data);
  }

  function openImportSheet() {
    openSheet(function () {
      var ta = h('textarea', { class: 'field', 'aria-label': 'بيانات للاستيراد', placeholder: 'الصق هنا النص المنسوخ من النسخة القديمة أو من نسخة احتياطية' });
      var err = h('div', { class: 'err-text' });
      return h('div', {},
        h('h2', { text: 'استيراد بيانات' }),
        h('p', { text: 'يدعم نسخة احتياطية من هذا التطبيق، أو بيانات النسخة القديمة (المفضلة والسجل). السجلات القديمة تظهر "غير مؤكدة" ولا تدخل في الإجماليات لأنها سُجّلت قبل معرفة النتيجة. كلمات السر لا تُستورد.' }),
        ta, err,
        h('div', { class: 'btn-row' },
          h('button', { class: 'btn', text: 'استيراد', onclick: function () {
            var obj;
            try { obj = JSON.parse(ta.value.trim()); } catch (e) { err.textContent = 'النص غير صالح'; return; }
            if (!obj || typeof obj !== 'object') { err.textContent = 'النص غير صالح'; return; }
            var msg;
            if (obj.app === 'codix-vip-pro') { var n = S.restoreBackup(obj); msg = 'استُعيد: ' + n.acc + ' حساب، ' + n.fav + ' مفضلة، ' + n.hist + ' عملية'; }
            else if (obj.favorites || obj.history) { var m = S.importLegacy(obj); msg = 'استُورد: ' + m.fav + ' مفضلة، ' + m.hist + ' عملية قديمة'; }
            else { err.textContent = 'لم يُعثر على بيانات معروفة في النص'; return; }
            closeSheet(); refreshAll(); toast(msg);
          } }),
          h('button', { class: 'btn sec', text: 'إلغاء', onclick: closeSheet })));
    });
  }

  // ---------- التنقل والعرض ----------

  function showTab(tab) {
    ui.tab = tab;
    ['home', 'balance', 'ops', 'accounts'].forEach(function (t) { $('view-' + t).hidden = t !== tab; });
    Array.prototype.forEach.call(document.querySelectorAll('.tab-btn'), function (b) {
      b.classList.toggle('active', b.getAttribute('data-tab') === tab);
    });
    refreshAll();
    window.scrollTo(0, 0);
  }

  function renderNotices() {
    var bar = $('noticeBar');
    clear(bar);
    function note(text, btn) {
      var n = h('div', { class: 'notice' }, text);
      if (btn) n.appendChild(h('button', { text: btn[0], onclick: btn[1] }));
      bar.appendChild(n);
    }
    if (!N.available) { note('وضع المتصفح: التنفيذ الداخلي وتشفير البيانات غير متاحين. استخدم تطبيق Android للحصول على كامل الميزات.'); return; }
    if (S.problem) note('تعذر قراءة البيانات المحفوظة سابقًا، فبدأ التطبيق ببيانات جديدة وحُفظت النسخة التالفة جانبًا.');
    if (!ui.perms.call || !ui.perms.phoneState) note('لتنفيذ العمليات وقراءة الشرائح داخل التطبيق يلزم منح الصلاحيات.', ['منح الصلاحيات', function () { N.requestPermissions(); }]);
    else if (!ui.device.ussdApiSupported) note('جهازك أقدم من Android 8: ستُنفَّذ العمليات عبر تطبيق الاتصال ولن تُعرف نتائجها تلقائيًا.');
  }

  function refreshAll() {
    renderNotices();
    renderStatsBits();
    renderFavorites();
    renderAccountBar();
    if (ui.tab === 'balance') renderBalance();
    if (ui.tab === 'ops') renderOps();
    if (ui.tab === 'accounts') renderAccounts();
  }

  // ---------- القفل ودورة الحياة ----------

  async function unlock() {
    $('lockMsg').textContent = '';
    var a = await N.auth('فتح CodiX VIP Pro', 'تحقق من هويتك');
    if (a.ok) { ui.locked = false; $('lockScreen').style.display = 'none'; askAboutDialerEntry(); }
    else $('lockMsg').textContent = 'تعذر التحقق، حاول مرة أخرى';
  }
  function lockNow() {
    if (!N.available || !S.d.settings.lockOnOpen || !ui.device.deviceSecure || ui.locked) return;
    ui.locked = true;
    closeSheet();
    $('lockScreen').style.display = 'flex';
    unlock();
  }

  window.onNativeBack = function () {
    if ($('devModal').style.display === 'flex') { $('devModal').style.display = 'none'; return true; }
    if (ui.sheetOpen) { if (!ui.sheetLocked) closeSheet(); return true; }
    if (ui.tab !== 'home') { showTab('home'); return true; }
    return false;
  };

  N.on('permissions', function () { refreshDevice(); refreshAll(); updatePinState(); });
  N.on('lifecycle', function (ev) {
    if (ev.state === 'pause') { ui.hiddenAt = Date.now(); S.flush(); }
    else if (ev.state === 'resume') {
      var away = ui.hiddenAt ? Date.now() - ui.hiddenAt : 0;
      ui.hiddenAt = 0;
      refreshDevice(); refreshAll();
      if (away > 120000) lockNow();
      if (!ui.locked) askAboutDialerEntry();
    }
  });

  // ---------- التهيئة ----------

  function init() {
    S.load();
    S.d.ui.type = S.d.ui.type || '1';
    // أي عملية بقيت "قيد المعالجة" لأن التطبيق أُغلق وسطها تصبح غير مؤكدة
    S.d.history.forEach(function (e) {
      if (e.status === 'pending') { e.status = 'unconfirmed'; e.detail = 'interrupted'; }
    });
    refreshDevice();
    N.setSecureScreen(S.d.settings.secureScreen);

    $('btnServiceJawwal').addEventListener('click', function () { setService('jawwal'); });
    $('btnServicePalpay').addEventListener('click', function () { setService('palpay'); });
    $('btnServiceBop').addEventListener('click', function () { setService('bop'); });
    $('btnNetJawwal').addEventListener('click', function () { setNetwork('jawwal'); });
    $('btnNetOoredoo').addEventListener('click', function () { setNetwork('ooredoo'); });
    $('btnFriend').addEventListener('click', function () { setType('1'); });
    $('btnMerchant').addEventListener('click', function () { setType('2'); });
    $('favSaveBtn').addEventListener('click', addCurrentToFavorites);
    $('clearBtn').addEventListener('click', clearInputs);
    $('clearBtn2').addEventListener('click', clearInputs);
    $('submitBtn').addEventListener('click', startTransfer);
    $('balanceBtn').addEventListener('click', homeBalanceClick);
    $('savePinCheckbox').addEventListener('change', onSavePinToggle);
    $('devBtn').addEventListener('click', function () { $('devModal').style.display = 'flex'; });
    $('devClose').addEventListener('click', function () { $('devModal').style.display = 'none'; });
    $('darkModeBtn').addEventListener('click', function () {
      S.d.settings.theme = isDark() ? 'light' : 'dark'; S.save(); applyTheme();
      if (ui.tab === 'accounts') renderAccounts();
    });
    $('unlockBtn').addEventListener('click', unlock);
    Array.prototype.forEach.call(document.querySelectorAll('.tab-btn'), function (b) {
      b.addEventListener('click', function () { showTab(b.getAttribute('data-tab')); });
    });

    $('phone').addEventListener('input', function () {
      var el = $('phone');
      var c = cleanPhone(el.value);
      if (c.length > 10) c = c.slice(0, 10);
      if (el.value !== c) el.value = c;
      updateCode(); detectName(c);
      if (c.length === 10) {
        if (c.indexOf('05') !== 0) toast('تنبيه: يجب أن يبدأ رقم الهاتف بـ 05');
        $('amount').focus();
      }
    });
    $('amount').addEventListener('input', function () {
      var el = $('amount');
      var v = el.value.replace(/[٠-٩]/g, function (d) { return String(d.charCodeAt(0) - 1632); }).replace(/[^0-9.]/g, '');
      var i = v.indexOf('.');
      if (i >= 0) v = v.slice(0, i + 1) + v.slice(i + 1).replace(/\./g, '');
      if (v.length > 7) v = v.slice(0, 7);
      if (el.value !== v) el.value = v;
      updateCode();
    });
    $('pin').addEventListener('input', function () {
      var el = $('pin');
      var v = el.value.replace(/\D/g, '').slice(0, 4);
      if (el.value !== v) el.value = v;
      updateCode();
    });
    if (window.matchMedia) {
      var mq = window.matchMedia('(prefers-color-scheme: dark)');
      if (mq.addEventListener) mq.addEventListener('change', applyTheme);
    }

    var u = S.d.ui;
    setNetwork(u.network === 'ooredoo' ? 'ooredoo' : 'jawwal');
    setService(['jawwal', 'palpay', 'bop'].indexOf(u.service) >= 0 ? u.service : 'jawwal');
    setType(u.type);
    applyTheme();
    showTab('home');
    if (S.problem && N.available) toast('تعذر قراءة البيانات السابقة وبدأ التطبيق ببيانات جديدة');
    lockNow();
    if (!ui.locked) askAboutDialerEntry();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
