/* CodiX VIP Pro - المزوّدون (Jawwal Pay / Ooredoo / PalPay / BOP)
 * كل مزوّد يعلن ما يدعمه فعليًا، والواجهة لا تعرض إلا ما هو معلن.
 * لا يوجد هنا أي رقم أو نتيجة افتراضية: التحليل يعمل على نص ردّ الشبكة فقط.
 */
(function (global) {
  'use strict';

  function normDigits(s) {
    return String(s == null ? '' : s)
      .replace(/[\u0660-\u0669]/g, function (d) { return String(d.charCodeAt(0) - 0x0660); })
      .replace(/[\u06F0-\u06F9]/g, function (d) { return String(d.charCodeAt(0) - 0x06F0); })
      .replace(/\u066B/g, '.').replace(/\u066C/g, ',');
  }

  // كلمات الفشل تُفحص أولًا: أي رد يحتويها لا يُعدّ نجاحًا أبدًا
  var FAIL_RE = new RegExp([
    'غير\\s*كاف', 'لا\\s*يوجد\\s*رصيد', 'رصيد(?:ك)?\\s*غير', 'خاطئ', 'خاطئة', 'غير\\s*صح', 'غير\\s*صالح',
    'فشل', 'لم\\s*ت?تم', 'لم\\s*يتم', 'مرفوض', 'رفض', 'تعذر', 'خطأ', 'غير\\s*ناجح', 'غير\\s*مكتمل',
    'غير\\s*مسموح', 'تجاوز', 'محظور', 'موقوف',
    'insufficient', 'invalid', 'incorrect', 'wrong', 'fail', 'error', 'declin', 'denied',
    'not\\s+enough', 'unable', 'cannot', "can't", 'not\\s+(?:successful|completed|allowed)',
    'unsuccessful', 'blocked', 'exceed'
  ].join('|'), 'i');

  // كلمات النجاح: تُعتمد فقط مع غياب كلمات الفشل وغياب القوائم التفاعلية
  var OK_RE = new RegExp([
    'بنجاح', 'ناجح(?:ة)?', 'تمت\\s+عملية', 'تم\\s+(?:ال)?تحويل', 'تم\\s+إرسال', 'تم\\s+ارسال', 'تم\\s+دفع',
    'successful', 'successfully', 'completed', 'transfer(?:red)?\\s+done'
  ].join('|'), 'i');

  var MENU_RE = /^\s*\d+\s*[\.\-\)\:]/m;

  var REF_RE = new RegExp(
    '(?:رقم\\s*(?:العملية|المعاملة|المرجع|مرجع(?:ي)?|الحوالة)|مرجع|reference(?:\\s*(?:no|number|id))?|' +
    'ref(?:\\.|\\s*no\\.?|\\s*#)?|transaction\\s*(?:id|no\\.?|number)|trx(?:\\s*id)?|txn(?:\\s*id)?)' +
    '\\s*[:#\\-=]?\\s*([A-Za-z0-9\\-]{5,24})', 'i');

  function isMenu(text) { return MENU_RE.test(normDigits(text)); }

  function extractRef(text) {
    var m = normDigits(text).match(REF_RE);
    return m ? m[1] : null;
  }

  /** تصنيف ردّ عملية تحويل: success فقط عند نص نجاح صريح، وغير ذلك failed أو unconfirmed. */
  function classifyTransfer(text) {
    var t = normDigits(text || '').trim();
    if (!t) return { status: 'unconfirmed', why: 'empty', ref: null };
    if (FAIL_RE.test(t)) return { status: 'failed', why: 'fail_words', ref: extractRef(t) };
    if (MENU_RE.test(t)) return { status: 'unconfirmed', why: 'menu', ref: null };
    if (OK_RE.test(t)) return { status: 'success', why: 'success_words', ref: extractRef(t) };
    return { status: 'unconfirmed', why: 'unknown', ref: extractRef(t) };
  }

  /** استخراج الرصيد من نص الرد فقط. يعيد رقمًا أو null. لا تقدير ولا قيمة افتراضية. */
  function parseBalance(text) {
    var t = normDigits(text || '');
    var num = '(\\d{1,3}(?:,\\d{3})+(?:\\.\\d{1,3})?|\\d+(?:\\.\\d{1,3})?)';
    var m, v;
    var re1 = new RegExp('(?:رصيد|balance)[^0-9\\n]{0,30}' + num, 'ig');
    while ((m = re1.exec(t))) {
      if (m[1].replace(/[^0-9]/g, '').length <= 7) { // يتجاهل أرقام الهواتف الطويلة
        v = parseFloat(m[1].replace(/,/g, ''));
        if (isFinite(v)) return v;
      }
    }
    var re2 = new RegExp(num + '\\s*(?:₪|شيكل|nis|ils)', 'ig');
    var seen = {}, count = 0, only = null;
    while ((m = re2.exec(t))) {
      if (!seen[m[1]]) { seen[m[1]] = 1; count++; only = m[1]; }
    }
    if (count === 1 && only.replace(/[^0-9]/g, '').length <= 7) {
      v = parseFloat(only.replace(/,/g, ''));
      if (isFinite(v)) return v;
    }
    return null;
  }

  var DEFS = {
    'jawwal:jawwal': {
      key: 'jawwal:jawwal', service: 'jawwal', network: 'jawwal',
      label: 'Jawwal Pay', netLabel: 'جوال', badge: 'badge-jawwal', color: '#0ba360',
      kind: 'transfer', hasType: true, needsPhone: true, needsAmount: true, needsPin: true,
      inApp: true, balanceCode: '*110*3#',
      code: function (p) { return '*110*' + p.type + '*' + p.pin + '*' + p.phone + '*' + p.amount + '*1#'; }
    },
    'jawwal:ooredoo': {
      key: 'jawwal:ooredoo', service: 'jawwal', network: 'ooredoo',
      label: 'Ooredoo', netLabel: 'وطنية', badge: 'badge-ooredoo', color: '#e61c24',
      kind: 'transfer', hasType: true, needsPhone: true, needsAmount: true, needsPin: true,
      inApp: true, balanceCode: '*268#',
      code: function (p) { return '*268*' + p.type + '*' + p.phone + '*' + p.amount + '*' + p.pin + '#'; }
    },
    'palpay': {
      key: 'palpay', service: 'palpay', network: null,
      label: 'PalPay', netLabel: '', badge: 'badge-palpay', color: '#7a28cb',
      kind: 'transfer', hasType: true, needsPhone: true, needsAmount: true, needsPin: false,
      inApp: false, balanceCode: null,
      code: function (p) {
        return p.type === '1' ? '*370*1*1*' + p.phone + '*' + p.amount + '#'
                              : '*370*2*' + p.phone + '*' + p.amount + '#';
      }
    },
    'bop': {
      key: 'bop', service: 'bop', network: null,
      label: 'بنك فلسطين', netLabel: '', badge: 'badge-bop', color: '#800B47',
      kind: 'login', hasType: false, needsPhone: false, needsAmount: false, needsPin: true,
      inApp: false, balanceCode: null,
      code: function (p) { return '*267*' + p.pin + '#'; }
    }
  };

  function get(service, network) {
    if (service === 'jawwal') return DEFS['jawwal:' + (network === 'ooredoo' ? 'ooredoo' : 'jawwal')];
    return DEFS[service] || DEFS['jawwal:jawwal'];
  }

  /** الكود الحقيقي (يتضمن PIN): يُستخدم للإرسال فقط ولا يُخزَّن ولا يُسجَّل. */
  function buildCode(def, p) { return def.code(p); }

  /** نسخة للعرض والتخزين: كلمة السر نجوم، وحقول فارغة نقاط. */
  function previewCode(def, p) {
    var pinLen = p.pin ? p.pin.length : 0;
    return def.code({
      type: p.type || '1',
      phone: p.phone || '...',
      amount: p.amount || '...',
      pin: pinLen > 0 ? new Array(pinLen + 1).join('*') : '...'
    });
  }

  global.Providers = {
    get: get, DEFS: DEFS, buildCode: buildCode, previewCode: previewCode,
    classifyTransfer: classifyTransfer, parseBalance: parseBalance,
    extractRef: extractRef, isMenu: isMenu, normDigits: normDigits
  };
})(typeof window !== 'undefined' ? window : globalThis);
