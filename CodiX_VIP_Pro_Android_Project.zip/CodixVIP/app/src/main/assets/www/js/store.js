/* CodiX VIP Pro - طبقة البيانات (حسابات، مفضلة، سجل، إعدادات).
 * داخل Android تُخزَّن مشفرة بمفتاح Keystore. في المتصفح تُخزَّن في localStorage بلا تشفير.
 */
(function (global) {
  'use strict';

  var MAX_HISTORY = 500;
  var data = null;
  var timer = null;
  var loadProblem = null;

  function fresh() {
    return {
      v: 1,
      settings: { theme: 'system', lockOnOpen: false, secureScreen: true, requireAuth: true, inApp: true },
      accounts: [],
      favorites: [],
      history: [],
      ui: { service: 'jawwal', network: 'jawwal', accountId: null }
    };
  }

  function uid() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 7); }

  function localDateStr(d) {
    var y = d.getFullYear(), m = d.getMonth() + 1, day = d.getDate();
    return y + '-' + (m < 10 ? '0' : '') + m + '-' + (day < 10 ? '0' : '') + day;
  }

  function load() {
    var res = Native.loadData();
    data = fresh();
    if (!res.ok) loadProblem = res.reason || 'unreadable';
    if (res.data) {
      try {
        var d = JSON.parse(res.data);
        data.settings = Object.assign(data.settings, d.settings || {});
        data.accounts = d.accounts || [];
        data.favorites = d.favorites || [];
        data.history = d.history || [];
        data.ui = Object.assign(data.ui, d.ui || {});
      } catch (e) { loadProblem = 'unreadable'; }
    } else if (!Native.available) {
      migrateBrowserLegacy();
    }
    return data;
  }

  // في المتصفح فقط: ترحيل بيانات النسخة القديمة من نفس المتصفح وحذف كلمات السر النصية
  function migrateBrowserLegacy() {
    try {
      var ls = global.localStorage, legacy = {};
      if (ls.getItem('codixFavorites')) legacy.favorites = JSON.parse(ls.getItem('codixFavorites'));
      if (ls.getItem('codixHistory')) legacy.history = JSON.parse(ls.getItem('codixHistory'));
      if (legacy.favorites || legacy.history) importLegacy(legacy);
      ['codix_pin_jawwal', 'codix_pin_ooredoo', 'codix_pin_palpay', 'codix_pin_bop', 'codix_pin_default']
        .forEach(function (k) { ls.removeItem(k); });
    } catch (e) { /* تجاهل */ }
  }

  function save() {
    clearTimeout(timer);
    timer = setTimeout(flush, 250);
  }
  function flush() {
    clearTimeout(timer);
    if (!data) return false;
    return Native.saveData(JSON.stringify(data));
  }

  /** استيراد بيانات النسخة القديمة (مفضلة + سجل). السجلات القديمة تُعتبر غير مؤكدة ولا تدخل في الإجماليات. */
  function importLegacy(obj) {
    var addedFav = 0, addedHist = 0;
    (obj.favorites || []).forEach(function (f) {
      if (!f || !f.phone) return;
      if (data.favorites.some(function (x) { return x.phone === f.phone; })) return;
      data.favorites.push({ name: String(f.name || f.phone), phone: String(f.phone), type: f.type === '2' ? '2' : '1', uses: f.uses || 0 });
      addedFav++;
    });
    var have = {};
    data.history.forEach(function (h) { have[h.id] = 1; });
    (obj.history || []).forEach(function (o) {
      if (!o || have['L' + o.id]) return;
      var ts = o.timestamp || Date.now();
      var svc = o.serviceKey || 'jawwal';
      data.history.push({
        id: 'L' + (o.id || uid()), ts: ts, dateStr: o.dateStr || localDateStr(new Date(ts)),
        kind: svc === 'bop' ? 'login' : 'transfer', accountId: null,
        service: svc, network: o.networkKey || null, typeCode: o.typeCode || '1',
        phone: svc === 'bop' ? '' : String(o.phone || ''), name: o.name || '',
        amount: svc === 'bop' ? 0 : (parseFloat(o.amount) || 0),
        status: 'unconfirmed', mode: 'dialer', legacy: true,
        reference: null, response: '', detail: 'legacy', code: ''
      });
      addedHist++;
    });
    data.history.sort(function (a, b) { return b.ts - a.ts; });
    if (data.history.length > MAX_HISTORY) data.history.length = MAX_HISTORY;
    save();
    return { fav: addedFav, hist: addedHist };
  }

  var Store = {
    uid: uid, localDateStr: localDateStr,
    load: load, save: save, flush: flush, importLegacy: importLegacy,
    get d() { return data; },
    get problem() { return loadProblem; },

    addHistory: function (e) {
      data.history.unshift(e);
      if (data.history.length > MAX_HISTORY) data.history.length = MAX_HISTORY;
      save();
      return e;
    },
    updateHistory: function (id, patch) {
      var e = data.history.filter(function (h) { return h.id === id; })[0];
      if (e) { Object.assign(e, patch); save(); }
      return e;
    },
    deleteHistory: function (id) {
      data.history = data.history.filter(function (h) { return h.id !== id; });
      save();
    },
    clearHistory: function () { data.history = []; save(); },

    /** استعادة نسخة احتياطية أنشأها هذا التطبيق (دمج بدون تكرار). */
    restoreBackup: function (obj) {
      var n = { acc: 0, fav: 0, hist: 0 };
      (obj.accounts || []).forEach(function (a) {
        if (a && a.id && !data.accounts.some(function (x) { return x.id === a.id; })) { data.accounts.push(a); n.acc++; }
      });
      (obj.favorites || []).forEach(function (f) {
        if (f && f.phone && !data.favorites.some(function (x) { return x.phone === f.phone; })) { data.favorites.push(f); n.fav++; }
      });
      (obj.history || []).forEach(function (h) {
        if (h && h.id && !data.history.some(function (x) { return x.id === h.id; })) { data.history.push(h); n.hist++; }
      });
      data.history.sort(function (a, b) { return b.ts - a.ts; });
      if (data.history.length > MAX_HISTORY) data.history.length = MAX_HISTORY;
      save();
      return n;
    },

    exportBackup: function () {
      // نسخة احتياطية بلا أي كلمات سر
      return JSON.stringify({ app: 'codix-vip-pro', v: 1, exportedAt: Date.now(), accounts: data.accounts, favorites: data.favorites, history: data.history });
    }
  };

  global.Store = Store;
})(window);
