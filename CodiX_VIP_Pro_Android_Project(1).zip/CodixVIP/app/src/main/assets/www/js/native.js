/* CodiX VIP Pro - واجهة موحدة للجسر الأصلي.
 * داخل تطبيق Android تستخدم الجسر. في المتصفح تتعطل الميزات الأصلية ويبقى الوضع البديل (tel:).
 */
(function (global) {
  'use strict';

  var B = global.CodixNative || null;
  var waiting = {};
  var seq = 0;
  var listeners = { permissions: [], lifecycle: [] };

  function parse(s, fallback) { try { return JSON.parse(s); } catch (e) { return fallback; } }

  global.onNativeEvent = function (ev) {
    if (!ev) return;
    if ((ev.type === 'ussd' || ev.type === 'auth') && waiting[ev.requestId]) {
      var f = waiting[ev.requestId];
      delete waiting[ev.requestId];
      f(ev);
    } else if (ev.type === 'permissions' || ev.type === 'lifecycle') {
      (listeners[ev.type] || []).forEach(function (fn) { try { fn(ev); } catch (e) { /* تجاهل */ } });
    }
  };

  function wait(id, ms, timeoutValue) {
    return new Promise(function (resolve) {
      var t = setTimeout(function () { delete waiting[id]; resolve(timeoutValue); }, ms);
      waiting[id] = function (ev) { clearTimeout(t); resolve(ev); };
    });
  }

  var Native = {
    available: !!B,
    on: function (type, fn) { (listeners[type] = listeners[type] || []).push(fn); },

    device: function () {
      if (!B) return { model: 'Browser', release: '', sdk: 0, ussdApiSupported: false, deviceSecure: false };
      return parse(B.getDeviceInfo(), {});
    },
    permissions: function () { return B ? parse(B.getPermissions(), { call: false, phoneState: false }) : { call: false, phoneState: false }; },
    requestPermissions: function () { if (B) B.requestPermissions(); },
    sims: function () {
      if (!B) return { ok: false, reason: 'browser', sims: [] };
      return parse(B.getSims(), { ok: false, reason: 'parse', sims: [] });
    },

    /** إرسال USSD فعلي. يعيد وعدًا بحدث النتيجة كما وصل من النظام. */
    ussd: function (code, subId) {
      if (!B) return Promise.resolve({ status: 'unsupported', detail: 'browser' });
      var id = 'u' + (++seq) + '_' + Date.now();
      var p = wait(id, 90000, { status: 'timeout', detail: 'bridge_timeout' });
      B.sendUssd(id, code, subId == null ? -1 : subId);
      return p;
    },
    dialer: function (code) {
      if (B) B.openDialer(code);
      else global.location.href = 'tel:' + code.replace(/#/g, '%23');
    },

    auth: function (title, subtitle) {
      if (!B) return Promise.resolve({ ok: true, reason: 'browser' });
      var id = 'a' + (++seq) + '_' + Date.now();
      var p = wait(id, 120000, { ok: false, reason: 'timeout' });
      B.authenticate(id, title || '', subtitle || '');
      return p;
    },

    loadData: function () {
      if (!B) {
        try { return { ok: true, data: global.localStorage.getItem('codixVipData') || '' }; }
        catch (e) { return { ok: true, data: '' }; }
      }
      return parse(B.loadData(), { ok: false, data: '' });
    },
    saveData: function (json) {
      if (!B) { try { global.localStorage.setItem('codixVipData', json); return true; } catch (e) { return false; } }
      return !!B.saveData(json);
    },

    pin: {
      supported: function () { return !!B; },
      has: function (key) { return B ? !!B.hasPin(key) : false; },
      save: function (key, pin) { return B ? parse(B.savePin(key, pin), { ok: false, reason: 'parse' }) : { ok: false, reason: 'browser' }; },
      get: function (key) { return B ? parse(B.getPin(key), { ok: false, reason: 'parse' }) : { ok: false, reason: 'browser' }; },
      remove: function (key) { if (B) B.removePin(key); }
    },

    setSecureScreen: function (on) { if (B) B.setSecureScreen(!!on); },
    copy: function (text) { if (B) { B.copyText(text); return true; } return false; },
    exit: function () { if (B) B.exitApp(); }
  };

  global.Native = Native;
})(window);
