package com.codix.vip

import android.Manifest
import android.annotation.TargetApi
import android.app.Activity
import android.app.KeyguardManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.biometrics.BiometricManager
import android.hardware.biometrics.BiometricPrompt
import android.net.Uri
import android.os.Build
import android.os.CancellationSignal
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.atomic.AtomicBoolean

/**
 * الجسر الوحيد بين الواجهة (JavaScript) وAndroid.
 * كل نتيجة تعود للواجهة كما وصلت من النظام أو الشبكة، بلا أي تعديل أو اختلاق.
 * لا تُكتب أكواد USSD (وفيها كلمة السر) في أي سجل.
 */
class NativeBridge(
    private val activity: Activity,
    private val web: WebView
) {
    private val main = Handler(Looper.getMainLooper())
    private val store = SecureStore(activity.applicationContext)

    // مهلة انتظار ردّ الشبكة (مللي ثانية)
    private val ussdTimeoutMs = 60_000L

    private var pendingCredReq: String? = null
    private val codeRegex = Regex("^[*#0-9]+$")
    private val keyRegex = Regex("^[A-Za-z0-9_\\-]{1,64}$")

    // ---------- معلومات الجهاز والصلاحيات ----------

    @JavascriptInterface
    fun getDeviceInfo(): String = JSONObject()
        .put("model", Build.MANUFACTURER + " " + Build.MODEL)
        .put("release", Build.VERSION.RELEASE)
        .put("sdk", Build.VERSION.SDK_INT)
        .put("ussdApiSupported", Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
        .put("deviceSecure", isDeviceSecure())
        .toString()

    @JavascriptInterface
    fun getPermissions(): String = JSONObject()
        .put("call", granted(Manifest.permission.CALL_PHONE))
        .put("phoneState", granted(Manifest.permission.READ_PHONE_STATE))
        .toString()

    @JavascriptInterface
    fun requestPermissions() {
        activity.runOnUiThread {
            if (Build.VERSION.SDK_INT >= 23) {
                activity.requestPermissions(
                    arrayOf(
                        Manifest.permission.CALL_PHONE,
                        Manifest.permission.READ_PHONE_STATE
                    ),
                    100
                )
            }
        }
    }

    fun onPermissionsResult() {
        emit(JSONObject().put("type", "permissions"))
    }

    fun emitLifecycle(state: String) {
        emit(JSONObject().put("type", "lifecycle").put("state", state))
    }

    // ---------- الشرائح ----------

    @Suppress("DEPRECATION")
    @JavascriptInterface
    fun getSims(): String {
        val out = JSONObject()
        val arr = JSONArray()
        if (!granted(Manifest.permission.READ_PHONE_STATE)) {
            return out.put("ok", false).put("reason", "no_permission").put("sims", arr).toString()
        }
        try {
            val sm = activity.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE)
                    as SubscriptionManager
            val list = sm.activeSubscriptionInfoList
            if (list != null) {
                for (info in list) {
                    val mcc: String
                    val mnc: String
                    if (Build.VERSION.SDK_INT >= 29) {
                        mcc = info.mccString ?: ""
                        mnc = info.mncString ?: ""
                    } else {
                        mcc = info.mcc.toString()
                        mnc = info.mnc.toString()
                    }
                    arr.put(
                        JSONObject()
                            .put("subId", info.subscriptionId)
                            .put("slot", info.simSlotIndex)
                            .put("carrier", info.carrierName?.toString() ?: "")
                            .put("display", info.displayName?.toString() ?: "")
                            .put("mcc", mcc)
                            .put("mnc", mnc)
                    )
                }
            }
            out.put("ok", true)
            if (Build.VERSION.SDK_INT >= 24) {
                out.put("defaultVoiceSubId", SubscriptionManager.getDefaultVoiceSubscriptionId())
            }
        } catch (e: SecurityException) {
            out.put("ok", false).put("reason", "security")
        } catch (e: Exception) {
            out.put("ok", false).put("reason", e.javaClass.simpleName)
        }
        return out.put("sims", arr).toString()
    }

    // ---------- تنفيذ USSD من داخل التطبيق ----------

    /**
     * يرسل كود USSD عبر واجهة Android الرسمية TelephonyManager.sendUssdRequest.
     * النتيجة تصل لاحقًا عبر الحدث "ussd" مع requestId نفسه.
     * subId = -1 يعني الشريحة الافتراضية.
     */
    @JavascriptInterface
    fun sendUssd(requestId: String, code: String, subId: Int) {
        val c = code.trim()
        val started = SystemClock.elapsedRealtime()

        fun fail(status: String, detail: String) {
            emit(
                JSONObject()
                    .put("type", "ussd").put("requestId", requestId)
                    .put("status", status).put("detail", detail)
                    .put("elapsedMs", SystemClock.elapsedRealtime() - started)
            )
        }

        if (c.length > 60 || !codeRegex.matches(c) || !c.startsWith("*") || !c.endsWith("#")) {
            fail("error", "invalid_format"); return
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            fail("unsupported", "android_below_8"); return
        }
        if (!granted(Manifest.permission.CALL_PHONE)) {
            fail("no_permission", "CALL_PHONE"); return
        }
        sendUssdApi26(requestId, c, subId, started)
    }

    @TargetApi(Build.VERSION_CODES.O)
    private fun sendUssdApi26(requestId: String, code: String, subId: Int, started: Long) {
        val done = AtomicBoolean(false)

        fun finish(status: String, detail: String, response: String?, failureCode: Int?) {
            if (!done.compareAndSet(false, true)) return
            val o = JSONObject()
                .put("type", "ussd").put("requestId", requestId)
                .put("status", status).put("detail", detail)
                .put("elapsedMs", SystemClock.elapsedRealtime() - started)
            if (response != null) o.put("response", response)
            if (failureCode != null) o.put("failureCode", failureCode)
            emit(o)
        }

        val timeout = Runnable { finish("timeout", "no_response_in_time", null, null) }

        try {
            var tm = activity.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            if (subId >= 0) tm = tm.createForSubscriptionId(subId)

            val callback = object : TelephonyManager.UssdResponseCallback() {
                override fun onReceiveUssdResponse(
                    telephonyManager: TelephonyManager,
                    request: String,
                    response: CharSequence
                ) {
                    main.removeCallbacks(timeout)
                    finish("response", "", response.toString(), null)
                }

                override fun onReceiveUssdResponseFailed(
                    telephonyManager: TelephonyManager,
                    request: String,
                    failureCode: Int
                ) {
                    main.removeCallbacks(timeout)
                    val name = when (failureCode) {
                        TelephonyManager.USSD_RETURN_FAILURE -> "USSD_RETURN_FAILURE"
                        TelephonyManager.USSD_ERROR_SERVICE_UNAVAIL -> "USSD_ERROR_SERVICE_UNAVAIL"
                        else -> "UNKNOWN"
                    }
                    finish("failed", name, null, failureCode)
                }
            }

            main.postDelayed(timeout, ussdTimeoutMs)
            tm.sendUssdRequest(code, callback, main)
        } catch (e: SecurityException) {
            main.removeCallbacks(timeout)
            finish("no_permission", "SecurityException", null, null)
        } catch (e: Exception) {
            main.removeCallbacks(timeout)
            finish("error", e.javaClass.simpleName, null, null)
        }
    }

    /** الوضع البديل: يفتح تطبيق الاتصال والكود معبّأ، والمستخدم يضغط اتصال بنفسه. */
    @JavascriptInterface
    fun openDialer(code: String) {
        val c = code.trim()
        if (!codeRegex.matches(c) || c.length > 60) return
        activity.runOnUiThread {
            val i = Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", c, null))
            try {
                activity.startActivity(i)
            } catch (_: Exception) {
            }
        }
    }

    // ---------- المصادقة (بصمة أو قفل الجهاز) ----------

    @JavascriptInterface
    fun isDeviceSecure(): Boolean {
        val km = activity.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        return km.isDeviceSecure
    }

    @Suppress("DEPRECATION")
    @JavascriptInterface
    fun authenticate(requestId: String, title: String, subtitle: String) {
        activity.runOnUiThread {
            val km = activity.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
            if (!km.isDeviceSecure) {
                emitAuth(requestId, false, "no_lock"); return@runOnUiThread
            }
            if (Build.VERSION.SDK_INT >= 30) {
                try {
                    val bp = BiometricPrompt.Builder(activity)
                        .setTitle(title)
                        .setSubtitle(subtitle)
                        .setAllowedAuthenticators(
                            BiometricManager.Authenticators.BIOMETRIC_STRONG or
                                BiometricManager.Authenticators.DEVICE_CREDENTIAL
                        )
                        .build()
                    bp.authenticate(
                        CancellationSignal(),
                        activity.mainExecutor,
                        object : BiometricPrompt.AuthenticationCallback() {
                            override fun onAuthenticationSucceeded(
                                result: BiometricPrompt.AuthenticationResult?
                            ) {
                                emitAuth(requestId, true, "")
                            }

                            override fun onAuthenticationError(
                                errorCode: Int,
                                errString: CharSequence?
                            ) {
                                emitAuth(requestId, false, "error_$errorCode")
                            }
                        }
                    )
                } catch (e: Exception) {
                    emitAuth(requestId, false, e.javaClass.simpleName)
                }
            } else {
                val i = km.createConfirmDeviceCredentialIntent(title, subtitle)
                if (i == null) {
                    emitAuth(requestId, false, "no_lock")
                } else {
                    pendingCredReq = requestId
                    activity.startActivityForResult(i, REQ_CREDENTIAL)
                }
            }
        }
    }

    fun onActivityResultFromSystem(requestCode: Int, resultCode: Int) {
        if (requestCode != REQ_CREDENTIAL) return
        val id = pendingCredReq ?: return
        pendingCredReq = null
        emitAuth(id, resultCode == Activity.RESULT_OK, if (resultCode == Activity.RESULT_OK) "" else "cancelled")
    }

    private fun emitAuth(requestId: String, ok: Boolean, reason: String) {
        emit(
            JSONObject().put("type", "auth").put("requestId", requestId)
                .put("ok", ok).put("reason", reason)
        )
    }

    // ---------- التخزين الآمن ----------

    @JavascriptInterface
    fun loadData(): String = store.loadData()

    @JavascriptInterface
    fun saveData(json: String): Boolean = store.saveData(json)

    @JavascriptInterface
    fun hasPin(key: String): Boolean = keyRegex.matches(key) && store.hasPin(key)

    @JavascriptInterface
    fun savePin(key: String, pin: String): String {
        if (!keyRegex.matches(key) || !Regex("^[0-9]{4}$").matches(pin)) {
            return JSONObject().put("ok", false).put("reason", "invalid").toString()
        }
        return store.savePin(key, pin)
    }

    @JavascriptInterface
    fun getPin(key: String): String {
        if (!keyRegex.matches(key)) {
            return JSONObject().put("ok", false).put("reason", "invalid").toString()
        }
        return store.getPin(key)
    }

    @JavascriptInterface
    fun removePin(key: String) {
        if (keyRegex.matches(key)) store.removePin(key)
    }

    // ---------- نظام ----------

    @JavascriptInterface
    fun setSecureScreen(enabled: Boolean) {
        activity.runOnUiThread {
            if (enabled) {
                activity.window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
            } else {
                activity.window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
            }
        }
    }

    @JavascriptInterface
    fun copyText(text: String) {
        activity.runOnUiThread {
            val cm = activity.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("CodiX", text))
        }
    }

    @JavascriptInterface
    fun exitApp() {
        activity.runOnUiThread { activity.finish() }
    }

    private fun granted(p: String): Boolean =
        activity.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun emit(o: JSONObject) {
        val quoted = JSONObject.quote(o.toString())
            .replace("\u2028", "\\u2028")
            .replace("\u2029", "\\u2029")
        val js = "window.onNativeEvent && window.onNativeEvent(JSON.parse($quoted))"
        main.post { web.evaluateJavascript(js, null) }
    }

    companion object {
        private const val REQ_CREDENTIAL = 201
    }
}
