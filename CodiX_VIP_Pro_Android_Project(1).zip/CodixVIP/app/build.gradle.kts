plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.codix.vip"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.codix.vip"
        minSdk = 23
        targetSdk = 36
        versionCode = 2
        versionName = "1.0.1-beta"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    lint {
        abortOnError = false
    }
}

// لا توجد أي مكتبات خارجية عمدًا: الحجم أخف وسطح الهجوم أصغر.
dependencies {
}
